#!/bin/bash 

# Variables
IMAGE_NAME="ed-nginx"
CONTAINER_NAME="some-nginx"
HOST_PORT=8080
CONTAINER_PORT=80

# Build
echo "Building the Docker image: $IMAGE_NAME"
docker build -t $IMAGE_NAME .

# Stop any running container with the same name
echo "Stopping any existing container with the name: $CONTAINER_NAME"
docker stop $CONTAINER_NAME > /dev/null 2>&1

# Remove any existing container with the same name
echo "Removing any existing container with the name: $CONTAINER_NAME"
docker rm $CONTAINER_NAME > /dev/null 2>&1

# Optionally, get and modify the nginx.conf file if needed
# Uncomment the lines below if you want to customize the nginx config.
# echo "Fetching default nginx configuration file."
# docker run --rm --entrypoint=cat nginx /etc/nginx/nginx.conf > nginx.conf
# echo "Customizing the nginx configuration file."
# docker run --name $CONTAINER_NAME -v $(pwd)/nginx.conf:/etc/nginx/nginx.conf:ro -d -p $HOST_PORT:$CONTAINER_PORT $IMAGE_NAME

# Run the container
echo "Running the Docker container on http://localhost:$HOST_PORT"
docker run --rm --name $CONTAINER_NAME -d -p $HOST_PORT:$CONTAINER_PORT $IMAGE_NAME

# Verify that the container is running
if [ $? -eq 0 ]; then
    echo "Container $CONTAINER_NAME is running and accessible at http://localhost:$HOST_PORT"
else
    echo "Failed to start the Docker container."
fi
