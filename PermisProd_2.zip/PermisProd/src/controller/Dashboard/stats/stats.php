<?php
ob_start(); // Commence le buffering ici
session_start(); // Initialise la session
require '../../../../config/conf_header.php';
require '../../../../src/view/component/header.php';
require '../../../controller/User/log/checkIsAdmin.php';

    // Récupérer les statistiques de l'utilisateur connecté
    $user_id = $_SESSION['user_id']; // Assurez-vous que l'ID de l'utilisateur est stocké dans la session

    $query_user_stats = "
        SELECT 
            COUNT(*) FILTER (WHERE validate = 't' AND score >= 80) AS validated,
            COUNT(*) FILTER (WHERE validate = 'f' OR score < 80) AS not_validated
        FROM test
        WHERE user_id = $1;
    ";

    $result_user_stats = pg_query_params($conn, $query_user_stats, [$user_id]);
    if ($result_user_stats) {
        $data_user_stats = pg_fetch_assoc($result_user_stats);
    } else {
        die("Erreur lors de la récupération des statistiques de l'utilisateur.");
    }

    // Récupérer la date du dernier test validé
    $query_last_validated = "
        SELECT passDate
        FROM test
        WHERE user_id = $1 AND validate = 't'
        ORDER BY passDate DESC
        LIMIT 1;
    ";

    $result_last_validated = pg_query_params($conn, $query_last_validated, [$user_id]);
    if ($result_last_validated) {
        $last_validated = pg_fetch_assoc($result_last_validated);
    } else {
        die("Erreur lors de la récupération de la date du dernier test validé.");
    }

    // Calcul des pourcentages
    $total_tests_user = $data_user_stats['validated'] + $data_user_stats['not_validated'];
    $avg_user_validated = $total_tests_user > 0 ? ($data_user_stats['validated'] / $total_tests_user * 100) : 0;
    $avg_user_not_validated = $total_tests_user > 0 ? ($data_user_stats['not_validated'] / $total_tests_user * 100) : 0;

    // Récupérer les statistiques pour le premier tour
    $query_first_round = "
        SELECT 
            COUNT(*) FILTER (WHERE validate = 't' AND score >= 80) AS validated,
            COUNT(*) FILTER (WHERE validate = 'f' OR score < 80) AS not_validated
        FROM (
            SELECT DISTINCT ON (user_id) user_id, validate, score
            FROM test
            ORDER BY user_id, passDate
        ) AS first_tests;
    ";

    $result_first_round = pg_query($conn, $query_first_round);
    if ($result_first_round) {
        $data_first_round = pg_fetch_assoc($result_first_round);
    } else {
        die("Erreur lors de la récupération des statistiques pour le premier tour.");
    }

    // Récupérer les statistiques pour le deuxième tour
    $query_second_round = "
        SELECT 
            COUNT(*) FILTER (WHERE validate = 't' AND score >= 80) AS validated,
            COUNT(*) FILTER (WHERE validate = 'f' OR score < 80) AS not_validated
        FROM (
            SELECT t.*
            FROM test t
            JOIN (
                SELECT user_id, MIN(passDate) AS first_passdate
                FROM test
                GROUP BY user_id
            ) AS first_attempts
            ON t.user_id = first_attempts.user_id AND t.passDate > first_attempts.first_passdate
        ) AS second_tests;
    ";

    $result_second_round = pg_query($conn, $query_second_round);
    if ($result_second_round) {
        $data_second_round = pg_fetch_assoc($result_second_round);
    } else {
        die("Erreur lors de la récupération des statistiques pour le deuxième tour.");
    }

    // Calcul des moyennes des réussites
    $total_users = $data_first_round['validated'] + $data_first_round['not_validated'];
    $total_users_second_round = $data_second_round['validated'] + $data_second_round['not_validated'];

    $avg_first_round = $data_first_round['validated'] / $total_users * 100;
    $avg_second_round = $data_second_round['validated'] / $total_users_second_round * 100;

    // Récupérer les statistiques générales
    $query_general_stats = "
        SELECT 
            COUNT(*) FILTER (WHERE validate = 't' AND score >= 80) AS validated,
            COUNT(*) FILTER (WHERE validate = 'f' OR score < 80) AS not_validated
        FROM test;
    ";

    $result_general_stats = pg_query($conn, $query_general_stats);
    if ($result_general_stats) {
        $data_general_stats = pg_fetch_assoc($result_general_stats);
    } else {
        die("Erreur lors de la récupération des statistiques générales.");
    }

    // Calcul des pourcentages
    $total_tests = $data_general_stats['validated'] + $data_general_stats['not_validated'];
    $avg_general_validated = $total_tests > 0 ? ($data_general_stats['validated'] / $total_tests * 100) : 0;
    $avg_general_not_validated = $total_tests > 0 ? ($data_general_stats['not_validated'] / $total_tests * 100) : 0;


    ?>

    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <title>Statistiques des Questionnaires</title>
        <link rel="stylesheet" href="stats.css">
        <link rel="stylesheet" href="../../../style/main.css"/>

    </head>
    <body>
        <h1 class="stats-title">Statistiques des Questionnaires</h1>
        <section class="stats">
            <!-- Statistiques du premier tour -->
            <div class="stats-theme-card">
                <div class="theme-name">Taux moyen 1er tour</div>
                <div class="stats-card-content">
                    <div class="stats-piechart">
                        <div class="pieChart" style="background: conic-gradient(var(--components-secondary-bg-colors) 0deg <?= round($avg_first_round * 3.6, 2) ?>deg, var(--components-bg-colors) <?= round($avg_first_round * 3.6, 2) ?>deg 360deg);"></div>
                        <span class="txtOne"><?= round($avg_first_round, 2) ?>%</span>
                        <span class="txtTwo"><?= round(100 - $avg_first_round, 2) ?>%</span>
                    </div>
                    <p><b><?= round($avg_first_round, 2) ?>%</b> des utilisateurs ont validé dès le premier coup.</p>
                </div>
            </div>

            <!-- Statistiques générales -->
            <div class="stats-theme-card">
                <div class="theme-name">Statistiques Générales</div>
                <div class="stats-card-content">
                    <div class="stats-piechart">
                        <div class="pieChart" style="background: conic-gradient(var(--components-secondary-bg-colors) 0deg <?= round($avg_general_validated * 3.6, 2) ?>deg, var(--components-bg-colors) <?= round($avg_general_validated * 3.6, 2) ?>deg 360deg);"></div>
                        <span class="txtOne"><?= round($avg_general_validated, 2) ?>%</span>
                        <span class="txtTwo"><?= round($avg_general_not_validated, 2) ?>%</span>
                    </div>
                    <p><b><?= round($avg_general_validated, 2) ?>%</b> des questionnaires ont été validés.</p>
                    <p><b><?= $data_general_stats['validated'] ?></b> questionnaires réussis sur <b><?= $total_tests ?></b> au total.</p>
                </div>
            </div>

            <div class="stats-theme-card">
                <div class="theme-name">Taux moyen 2em tour</div>
                <div class="stats-card-content">
                    <div class="stats-piechart">
                        <div class="pieChart" style="background: conic-gradient(var(--components-secondary-bg-colors) 0deg <?= round($avg_second_round * 3.6, 2) ?>deg, var(--components-bg-colors) <?= round($avg_second_round * 3.6, 2) ?>deg 360deg);"></div>
                        <span class="txtOne"><?= round($avg_second_round, 2) ?>%</span>
                        <span class="txtTwo"><?= round(100 - $avg_second_round, 2) ?>%</span>
                    </div>
                    <p><b><?= round($avg_second_round, 2) ?>%</b> des utilisateurs ont validé dès le deuxième coup.</p>
                </div>
            </div>

            <!-- Statistiques de l'utilisateur connecté -->
            <div class="stats-theme-card">
                <div class="theme-name">Vos Statistiques</div>
                <div class="stats-card-content">
                    <div class="stats-piechart">
                        <div class="pieChart" style="background: conic-gradient(var(--components-secondary-bg-colors) 0deg <?= round($avg_user_validated * 3.6, 2) ?>deg, var(--components-bg-colors) <?= round($avg_user_validated * 3.6, 2) ?>deg 360deg);"></div>
                        <span class="txtOne"><?= round($avg_user_validated, 2) ?>%</span>
                        <span class="txtTwo"><?= round($avg_user_not_validated, 2) ?>%</span>
                    </div>
                    <p><b><?= round($avg_user_validated, 2) ?>%</b> de vos questionnaires ont été validés.</p>
                    <?php if ($last_validated): ?>
                        <p>Dernier questionnaire validé le : <b><?= htmlspecialchars(date('d M Y', strtotime($last_validated['passdate']))) ?></b></p>
                    <?php else: ?>
                        <p>Aucun questionnaire validé pour le moment.</p>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <script>
            // Détecter quand la souris quitte la fenêtre
            document.addEventListener('mouseleave', function() {
                document.body.classList.add('screenshot-blocked');
            });

            // Détecter quand la souris revient sur la fenêtre
            document.addEventListener('mouseenter', function() {
                document.body.classList.remove('screenshot-blocked');
            });
            document.addEventListener('keydown', (event) => {
            
                // Détecter la touche Impr écran (PrtScn)
            if (event.key === 'PrintScreen' || (event.ctrlKey && event.key === 'p')) {
                event.preventDefault();
                alert('Les captures d\'écran sont désactivées sur ce site.');
            }
            });

            document.addEventListener('contextmenu', (event) => {
            event.preventDefault();
            alert('Le clic droit est désactivé sur ce site.');
            });

            document.addEventListener('copy', (event) => {
            event.preventDefault();
            alert('Le copier est désactivé sur ce site.');
            });

            document.addEventListener('cut', (event) => {
                event.preventDefault();
                alert('Le couper est désactivé sur ce site.');
            });

            document.addEventListener('paste', (event) => {
                event.preventDefault();
                alert('Le coller est désactivé sur ce site.');
            });

            document.addEventListener('keydown', (event) => {
                // Détecter Ctrl + S (ou Cmd + S sur Mac)
                if ((event.ctrlKey || event.metaKey) && event.key === 's') {
                    event.preventDefault();
                    alert('L\'enregistrement de la page est désactivé.');
                }
            });

            // Détecter l'ouverture des outils de développement
            let devToolsOpened = false;

            setInterval(() => {
                const widthThreshold = window.outerWidth - window.innerWidth > 160;
                const heightThreshold = window.outerHeight - window.innerHeight > 160;

                if ((widthThreshold || heightThreshold) && !devToolsOpened) {
                    devToolsOpened = true;
                    alert('Les outils de développement sont désactivés.');
                    window.location.reload(); // Recharger la page
                }
            }, 1000);

            // Intercepter F12, Ctrl + Shift + I, Ctrl + Shift + C
            document.addEventListener('keydown', (event) => {
                if (
                    event.key === 'F12' ||
                    (event.ctrlKey && event.shiftKey && event.key === 'I') ||
                    (event.ctrlKey && event.shiftKey && event.key === 'C')
                ) {
                    event.preventDefault();
                    alert('Les outils de développement sont désactivés.');
                }
            });
        </script>
    </body>
</html>

<?php
require '../../../../src/view/component/footer.php';
require '../../../../config/conf_footer.php';
?>