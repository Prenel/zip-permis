<?php
ob_start();
session_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require '../../../../config/conf_header.php';
require_once '../../../../config/config.php';
require '../../../../vendor/autoload.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Vérification des variables de session
$user_id  = $_SESSION['user_id'];
$username = $_SESSION['username'];
$email    = $_SESSION['manager'];

/* // Vérification avant de continuer
if ($_SESSION['user_id'] == null || $_SESSION['manager'] == null) {
    echo "$user_id + $username + $email + Erreur : Les informations utilisateur sont manquantes.";
    exit;
} */

// Requête pour récupérer les tests de l'utilisateur
$query = "
    SELECT t.id AS test_id, t.score, t.validate, t.passDate
    FROM test t
    WHERE t.user_id = $1
    ORDER BY t.id DESC
";
$result = pg_query_params($conn, $query, array($user_id));

if (!$result) {
    echo "Erreur lors de la récupération des tests : " . pg_last_error($conn);
    exit;
}

$tests = pg_fetch_all($result);
if (!$tests) {
    echo "Aucun questionnaire trouvé pour cet utilisateur.";
    exit;
}

// Génération du contenu de l'email
$email_content = <<<HTML
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Historique des questionnaires</title>
</head>
<body>
    <h1>Historique des questionnaires de l'utilisateur <font color="lightgray">{$username}</font></h1>
    <ul>
        <li>
            <a href="https://cagip.edbackend.eu/src/controller/User/data/historic.php?user_id={$user_id}"> <!-- Changer pour url du site  -->
                <button title="Visualisez les résultats de votre équipe !">Visualisez les résultats de votre équipe !</button>
            </a>
        </li>
    </ul>
</body>
</html>
HTML;

function sendEmailViaInternalSMTP($email, $username, $email_content) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = '10.245.192.12';
        $mail->Port = 25;
        $mail->SMTPAuth = false;

        $mail->setFrom('no-reply@cagip.com', 'CAGIP');
        $mail->addAddress($email, $username);

        $mail->isHTML(true);
        $mail->Subject = 'PermisProd : ' . $username;
        $mail->Body    = $email_content;

        if (!$mail->send()) {
            throw new Exception('Erreur lors de l\'envoi via le serveur SMTP interne: ' . $mail->ErrorInfo);
        }
        return true;
    } catch (Exception $e) {
        error_log($e->getMessage());
        return false;
    }
}

if (sendEmailViaInternalSMTP($email, $username, $email_content)) {
    header('Location: historic.php?user_id=' . $user_id);
} else {
    echo "Erreur lors de l'envoi de l'email.";
}

?>