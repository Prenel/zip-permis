<?php ob_start(); session_start();?>
<?php require '../../../../config/conf_header.php'?>

<head>
    <title>LogIn</title>
    <link rel="stylesheet" href="login.css"/>
    <link rel="stylesheet" href="../../../style/main.css"/>
</head>



<div class="login">
    <h1 class="titre-login">CA-GIP Permis de Production</h1>

    <div class="loginForm"> 
        <h2>Connexion</h2>  
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error">
                <?php
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>
        <form method="post" action="settingLogIn.php">
            <div class="formGroup">
                <label for="email">Adresse mail : <br> </label>
                <input type="text" id="email" name="email" maxlength="255" required>
            </div>
            <div class="formGroup">
                <label for="password">Mot de passe : <br> </label>  
                <input type="password" id="password" name="password" required>
            </div>
            <div class="formGroup">
                <button type="submit" title="Se connecter">Se connecter</button>
            </div>
        </form>
    </div>
</div>
<script>
    // Détecter quand la souris quitte la fenêtre
    document.addEventListener('mouseleave', function() {
        document.body.classList.add('screenshot-blocked');
    });

    // Détecter quand la souris revient sur la fenêtre
    document.addEventListener('mouseenter', function() {
        document.body.classList.remove('screenshot-blocked');
    });
    document.addEventListener('keydown', (event) => {
    
        // Détecter la touche Impr écran (PrtScn)
    if (event.key === 'PrintScreen' || (event.ctrlKey && event.key === 'p')) {
        event.preventDefault();
        alert('Les captures d\'écran sont désactivées sur ce site.');
    }
    });

    document.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    alert('Le clic droit est désactivé sur ce site.');
    });

    document.addEventListener('keydown', (event) => {
        // Détecter Ctrl + S (ou Cmd + S sur Mac)
        if ((event.ctrlKey || event.metaKey) && event.key === 's') {
            event.preventDefault();
            alert('L\'enregistrement de la page est désactivé.');
        }
    });

    // Détecter l'ouverture des outils de développement
    let devToolsOpened = false;

    setInterval(() => {
        const widthThreshold = window.outerWidth - window.innerWidth > 160;
        const heightThreshold = window.outerHeight - window.innerHeight > 160;

        if ((widthThreshold || heightThreshold) && !devToolsOpened) {
            devToolsOpened = true;
            alert('Les outils de développement sont désactivés.');
            window.location.reload(); // Recharger la page
        }
    }, 1000);

    // Intercepter F12, Ctrl + Shift + I, Ctrl + Shift + C
    document.addEventListener('keydown', (event) => {
        if (
            event.key === 'F12' ||
            (event.ctrlKey && event.shiftKey && event.key === 'I') ||
            (event.ctrlKey && event.shiftKey && event.key === 'C')
        ) {
            event.preventDefault();
            alert('Les outils de développement sont désactivés.');
        }
    });
</script>