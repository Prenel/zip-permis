<?php
ob_start();
require '../../../../config/conf_header.php';
require '../../../../src/view/component/header.php';
require '../../../controller/User/log/checkIsAdmin.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Gestion du tri par colonnes
$order_by = $_GET['order_by'] ?? 'cluster'; // Par défaut, tri par cluster
$order_dir = $_GET['order_dir'] ?? 'asc'; // Par défaut, tri croissant

// Colonnes valides pour le tri
$valid_columns = ['id', 'cluster', 'username', 'mail', 'pass', 'firstName', 'lastName', 'team', 'manager', 'isadmin'];
if (!in_array($order_by, $valid_columns)) {
    $order_by = 'cluster';
}

// Direction de tri
$order_dir = ($order_dir === 'desc') ? 'desc' : 'asc';

// Construire la requête avec tri
$query = "SELECT * FROM users ORDER BY $order_by $order_dir";
$users = pg_query($conn, $query);
if (!$users) {
    echo "<pre>Erreur PostgreSQL lors de la récupération des utilisateurs :\n" . pg_last_error($conn) . "\n</pre>";
    die("Erreur : Impossible de récupérer les utilisateurs.");
}

// Gestion des opérations : Ajouter, Modifier, Supprimer un utilisateur
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        switch ($action) {
        case 'add_user':
            $username = $_POST['username'];
            $mail = $_POST['mail'];
            $password = $_POST['pass'];
            $firstName = $_POST['firstName'];
            $lastName = $_POST['lastName'];
            $cluster = $_POST['cluster'];
            $team = substr($_POST['team'], 0, 16);
            $manager = $_POST['manager'];
            $isadmin = ($_POST['isadmin'] === 'true') ? 'TRUE' : 'FALSE';
            $validationState = 'FALSE';

            $query = "INSERT INTO users (username, mail, pass, firstName, lastName, cluster, team, manager, isadmin, validationState) 
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)";
            $result = pg_query_params($conn, $query, [
                $username, $mail, $password, $firstName, $lastName, $cluster, $team, $manager, $isadmin, $validationState
            ]);

            if (!$result) {
                echo "<pre>Erreur PostgreSQL :\n" . pg_last_error($conn) . "\n</pre>";
                die("Erreur : Impossible d'ajouter l'utilisateur.");
            }
            break;

            case 'edit_user':
                $user_id = (int) $_POST['user_id'];
                $username = substr($_POST['username'], 0, 32);
                $mail = filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL);
                $password = substr($_POST['pass'], 0, 64);
                $firstName = substr($_POST['firstName'] ?? '', 0, 32);
                $lastName = substr($_POST['lastName'] ?? '', 0, 32);
                $cluster = substr($_POST['cluster'], 0, 16);
                $team = substr($_POST['team'], 0, 16);
                $manager = substr($_POST['manager'], 0, 64);
                
                // Conversion explicite de isadmin en booléen
                $isadmin = ($_POST['isadmin'] === 't') ? 't' : 'f'; // Notez l'absence de majuscules ici
            
                // Vérification de l'adresse e-mail
                if (!$mail) {
                    die("Erreur : L'adresse e-mail n'est pas valide.");
                }
            
                // Requête SQL pour mettre à jour les données
                $query = "
                    UPDATE users
                    SET username = $1, mail = $2, pass = $3, firstName = $4, lastName = $5,
                        cluster = $6, team = $7, manager = $8, isadmin = $9
                    WHERE id = $10
                ";
            
                // Paramètres pour la requête
                $result = pg_query_params($conn, $query, [
                    $username, $mail, $password, $firstName, $lastName,
                    $cluster, $team, $manager, $isadmin, $user_id
                ]);
            
                // Vérification de la réussite de la requête
                if (!$result) {
                    echo "<pre>Erreur PostgreSQL lors de la modification :\n" . pg_last_error($conn) . "\n</pre>";
                    die("Erreur : Impossible de modifier l'utilisateur.");
                }
                break;
                

            case 'delete_user':
                $user_id = (int) $_POST['user_id'];

                $query = "DELETE FROM users WHERE id = $1";
                $result = pg_query_params($conn, $query, [$user_id]);

                if (!$result) {
                    echo "<pre>Erreur PostgreSQL lors de la suppression :\n" . pg_last_error($conn) . "\n</pre>";
                    die("Erreur : Impossible de supprimer l'utilisateur.");
                }
                break;
        }
    }
}
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Utilisateurs</title>
    <link rel="stylesheet" href="user.css"/>
    <link rel="stylesheet" href="../../../style/main.css"/>
</head>
<body>
    <!-- Affichage des utilisateurs -->
    <h1>Gestion des Utilisateurs</h1>
    <div class="csv-presentation">
        <h3><a href="user_csv.php"> ➡️ CSV ADD </a></h3>
    </div>
    <h2>Utilisateurs</h2>
    <table>
        <thead>
            <tr>
                <?php
                foreach ($valid_columns as $column) {
                    $new_dir = ($order_by === $column && $order_dir === 'asc') ? 'desc' : 'asc';
                    $arrow = ($order_by === $column) ? ($order_dir === 'asc' ? '⬆️' : '⬇️') : '⬍';
                    $style = ($order_by === $column) ? 'text-decoration: underline;' : '';
                    echo "<th><a href=\"?order_by=$column&order_dir=$new_dir\" style=\"$style\">" . ucfirst($column) . " $arrow</a></th>";
                }
                ?>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($user = pg_fetch_assoc($users)) : ?>
                <tr>
                    <form method="POST">
                        <input type="hidden" name="user_id" value="<?= htmlspecialchars($user['id']) ?>">
                        <?php foreach ($valid_columns as $column): ?>
                            <td>
                                <?php if ($column === 'pass'): ?>
                                    <!-- Champ mot de passe masqué -->
                                    <input type="password" name="<?= $column ?>" value="<?= htmlspecialchars($user[$column] ?? '') ?>">
                                <?php elseif (in_array($column, ['firstName', 'lastName'])): ?>
                                    <!-- Champs firstName et lastName non requis -->
                                    <input type="text" name="<?= $column ?>" value="<?= htmlspecialchars($user[$column] ?? '') ?>">
                                <?php else: ?>
                                    <input type="text" name="<?= $column ?>" value="<?= htmlspecialchars($user[$column] ?? '') ?>">
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                        <td>
                            <button type="submit" name="action" value="edit_user">Modifier</button>
                            <button type="submit" name="action" value="delete_user" style="color: red;">Supprimer</button>
                        </td>
                    </form>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <?php
        // Récupérer le max ID des utilisateurs
        $max_id_user_query = pg_query($conn, "SELECT MAX(id) AS max_id FROM users");
        $max_id_user_row = pg_fetch_assoc($max_id_user_query);
        $max_id_user = $max_id_user_row['max_id'];
    ?>
    <tfoot>
        <tr>
            <td colspan="<?= count($valid_columns) + 1 ?>" style="text-align: center;">
                <strong>Max ID des utilisateurs : <?= htmlspecialchars($max_id_user) ?></strong>
            </td>
        </tr>
    </tfoot>

    <!-- Formulaire pour ajouter un utilisateur -->
    <h2>Ajouter un utilisateur</h2>
    <form method="POST">
        <input type="hidden" name="action" value="add_user">
        <table>
            <tr>
                <td><label for="cluster">Cluster/Socle :</label></td>
                <td><input required minlength="3" maxlength="9" type="text" id="cluster" name="cluster" required></td>
                <td><p>CXI, CIB, BPC, BPCR, GEA, Paiements, SFS</p></td>
            </tr>
            <tr>
                <td><label for="username">Nom d'utilisateur :</label></td>
                <td><input required minlength="4" maxlength="12" type="text" id="username" name="username" required></td>
                <td><p>JohnDoe</p></td>
            </tr>
            <tr>
                <td><label for="mail">Mail :</label></td>
                <td><input required minlength="8" maxlength="252" type="email" id="mail" name="mail" required></td>
                <td><p>john-doe@exemple.com</p></td>
            </tr>
            <tr>
                <td><label for="pass">Mot de passe :</label></td>
                <td><input required minlength="8" maxlength="30" type="password" id="pass" name="pass" required></td>
                <td><p>Password</p></td>
            </tr>
            <tr>
                <td><label for="firstName">Prénom :</label></td>
                <td><input type="text" id="firstName" name="firstName"></td>
                <td><p>John</p></td>
            </tr>
            <tr>
                <td><label for="lastName">Nom :</label></td>
                <td><input type="text" id="lastName" name="lastName"></td>
                <td><p>Doe</p></td>
            </tr>
            <tr>
                <td><label for="team">Équipe :</label></td>
                <td><input required minlength="3" maxlength="9" type="text" id="team" name="team"></td>
                <td><p>CXI, CIB, BPC, BPCR, GEA, Paiements, SFS</p></td>
            </tr>
            <tr>
                <td><label for="manager">Manager :</label></td>
                <td><input required minlength="8" maxlength="252" type="email" id="manager" name="manager" required></td>
                <td><p>john-doe-manager@exemple.com</p></td>
            </tr>
            <tr>
                <td><label for="isadmin">Admin :</label></td>
                <td>
                    <select name="isadmin">
                        <option value="true" <?= ($user['isadmin'] === 't') ? 'selected' : '' ?>>Oui</option>
                        <option value="false" <?= ($user['isadmin'] === 'f') ? 'selected' : '' ?>>Non</option>
                    </select>
                </td>
                <td><p>Admin / User</p></td>
            </tr>
        </table>
        <button type="submit">Ajouter</button>
    </form>
    <script>
        // Détecter quand la souris quitte la fenêtre
        document.addEventListener('mouseleave', function() {
            document.body.classList.add('screenshot-blocked');
        });

        // Détecter quand la souris revient sur la fenêtre
        document.addEventListener('mouseenter', function() {
            document.body.classList.remove('screenshot-blocked');
        });
    </script>
</body>
</html>