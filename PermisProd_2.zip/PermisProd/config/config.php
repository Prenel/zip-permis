<?php
// LOCAL SETTINGS 
$leader_ip = "localhost"; // IP de la bdd
$localport = "5432";


// COMMANDE METTRE DANS USB / DUMP
    // psql -U test -d permisprod
    // psql -U test -h localhost -d permisprod -f /home/paul-preuvost/Desktop/PermisProd.tar.gz


// Connexion à la base de données PostgreSQL

try {
    $conn = pg_connect("host=$leader_ip dbname=permisprod user=test password=@test2024 port=$localport");
    if (!$conn) {
        throw new Exception("Erreur de connexion à la base de données.");
    }
} catch (Exception $e) {
    echo "Une erreur s'est produite : " . $e->getMessage();
    exit;
}
?>
