<?php ob_start(); 

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (!isset($_SESSION['user_id'], $_SESSION['token'])) {
    header('Location: ../../src/controller/User/log/login.php');
    exit;
}

?>