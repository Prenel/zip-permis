<?php ob_start(); 
require '../../../../config/conf_header.php';
require '../../../../src/view/component/header.php';
require '../log/checkAuth.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$Username = $_SESSION['username'] ?? 'Utilisateur';
$Role = (string) $_SESSION['isadmin'] ? 'Admin' : 'User';
$user_id = $_SESSION['user_id']; 

// Récupérer la date du dernier test validé
$query_last_validated = "
    SELECT passDate
    FROM test
    WHERE user_id = $1 AND validate = 't'
    ORDER BY passDate DESC
    LIMIT 1;
    ";


$result_last_validated = pg_query_params($conn, $query_last_validated, [$user_id]);
if ($result_last_validated) {
    $last_validated = pg_fetch_assoc($result_last_validated);
} else {
    die("Erreur lors de la récupération de la date du dernier test validé.");
}

// Récupérer validationState depuis la base de données
$query_validation_state = "
    SELECT validationState
    FROM users
    WHERE id = $1;
";

$result_validation_state = pg_query_params($conn, $query_validation_state, [$user_id]);
if ($result_validation_state) {
    $row = pg_fetch_assoc($result_validation_state);
    $validationState = $row['validationstate']; // Enregistrer la valeur dans une variable
} else {
    die("Erreur lors de la récupération de validationState depuis la base de données.");
}


?>

<head>
    <title>Page Utilisateur</title>
    <link rel="stylesheet" href="user.css">
    <link rel="stylesheet" href="../../../style/main.css">
</head>

<section class="user-section">
    <div class="user">
        <div class="user-welcome">
            <h2>Bonjour, <span class="username"><?php echo htmlspecialchars($Username); ?></span> !</h2>



            <p class="user-status">Votre statut : <span class="<?php echo ($validationState == 't') ? 'valide status' : 'non-valide status'; ?>"><?php echo ($validationState == 't') ? 'Validé' : 'Non validé'; ?></span></p>

            <!--<p class="user-status">Votre statut DEBUG: <span><?php echo $validationState; ?></span></p>-->




            <p class="user-date">Dernier questionnaire validé le : 
                <span>
                    <?php if ($last_validated): ?>
                        <?= htmlspecialchars(date('d M Y', strtotime($last_validated['passdate']))) ?>
                    <?php else: ?>
                        Aucun questionnaire validé pour le moment.
                    <?php endif; ?>
                </span>
            </p>

            <p class="user-status">Votre rôle : <span class="<?php echo ($_SESSION['isadmin'] == 'true') ? 'role-admin' : 'role-user'; ?>"><?php echo htmlspecialchars($Role); ?></span></p>
        </div>

        <!-- Section réservée aux administrateurs -->
        <?php if ($_SESSION['isadmin']) : ?>
            <div class="user-dashboard-stats">
                <a href="../../Dashboard/stats/stats.php"><button title="Voir les statistiques des tests" class="button user-button">Dashboard</button></a>
            </div>
            
            <div class="admin-section">
                <div class="user-management">
                    <a href="../../Admin/user/user.php">

                        <button class="button user-button">User Management</button>
                    </a>
                </div>
                <div class="test-management">
                    <a href="../../Admin/question/question.php">

                        <button class="button user-button">Test Management</button>
                    </a>
                </div>
            </div>
        <?php endif; ?>


        <div class="user-actions">
            <div class="user-result">
                <a href="../data/historic.php?<?echo $user_id?>; ?>">
                    <button title="Voir l'historique des tests" class="button user-button">Historique</button>
                </a>
            </div>
            <div class="user-disconnect">
                <a href="../log/logout.php"><button title="Déconnexion" class="button user-button">Déconnexion</button></a>
            </div>
        </div>
    </div>
</section>

<script>
    // Détecter quand la souris quitte la fenêtre
    document.addEventListener('mouseleave', function() {
        document.body.classList.add('screenshot-blocked');
    });

    // Détecter quand la souris revient sur la fenêtre
    document.addEventListener('mouseenter', function() {
        document.body.classList.remove('screenshot-blocked');
    });
    document.addEventListener('keydown', (event) => {
    
        // Détecter la touche Impr écran (PrtScn)
    if (event.key === 'PrintScreen' || (event.ctrlKey && event.key === 'p')) {
        event.preventDefault();
        alert('Les captures d\'écran sont désactivées sur ce site.');
    }
    });

    document.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    alert('Le clic droit est désactivé sur ce site.');
    });

    document.addEventListener('copy', (event) => {
    event.preventDefault();
    alert('Le copier est désactivé sur ce site.');
    });

    document.addEventListener('cut', (event) => {
        event.preventDefault();
        alert('Le couper est désactivé sur ce site.');
    });

    document.addEventListener('paste', (event) => {
        event.preventDefault();
        alert('Le coller est désactivé sur ce site.');
    });

    document.addEventListener('keydown', (event) => {
        // Détecter Ctrl + S (ou Cmd + S sur Mac)
        if ((event.ctrlKey || event.metaKey) && event.key === 's') {
            event.preventDefault();
            alert('L\'enregistrement de la page est désactivé.');
        }
    });

    // Détecter l'ouverture des outils de développement
    let devToolsOpened = false;

    setInterval(() => {
        const widthThreshold = window.outerWidth - window.innerWidth > 160;
        const heightThreshold = window.outerHeight - window.innerHeight > 160;

        if ((widthThreshold || heightThreshold) && !devToolsOpened) {
            devToolsOpened = true;
            alert('Les outils de développement sont désactivés.');
            window.location.reload(); // Recharger la page
        }
    }, 1000);

    // Intercepter F12, Ctrl + Shift + I, Ctrl + Shift + C
    document.addEventListener('keydown', (event) => {
        if (
            event.key === 'F12' ||
            (event.ctrlKey && event.shiftKey && event.key === 'I') ||
            (event.ctrlKey && event.shiftKey && event.key === 'C')
        ) {
            event.preventDefault();
            alert('Les outils de développement sont désactivés.');
        }
    });
</script>

<?php require '../../../view/component/footer.php'; ?>
<?php require '../../config/conf_footer.php'; ?>
