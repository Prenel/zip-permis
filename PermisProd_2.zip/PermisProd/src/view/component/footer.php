<section class="footer">
    <div class="footer-logo">
        <a href="../../../../../../index.php" title="Page d'Accueil">
            <img src="../../../../../public/src/images/LogoCAblanc.svg" alt="Logo CA" class="logo-footer">
        </a>
    </div>

    <div class="footer-column">
        <h3>Contact</h3>
        <p><a href="mailto:permisdeproduction@ca-gip.fr" style="color: #fff; text-decoration: underline;">permisdeproduction@ca-gip.fr</a></p>
    </div>

    <div class="footer-column">
        <h3>Corpus Documentaire</h3>
        <p style="color: #bbb;">Coming Soon</p>
        <p style="color: #bbb;">Version 1.0.1</p>
    </div>

    <div class="footer-column">
        <h3>Qualité de Service</h3>
        <p><a href="https://cacommun.sharepoint.com/sites/qualite-de-services" target="_blank" style="color: #fff; text-decoration: underline;">Visitez notre page Qualité de Service</a></p>
    </div>
</section>