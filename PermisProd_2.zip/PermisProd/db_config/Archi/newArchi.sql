CREATE TABLE Question (
    Id SERIAL PRIMARY KEY,
    Theme VARCHAR(255),
    IdTheme INT,
    Question TEXT,
    QuestionNumberAwnser INT UNIQUE
);

CREATE TABLE Reponse (
    Id SERIAL PRIMARY KEY,
    QuestionID INT,
    Reponse VARCHAR(255),
    ReponseCorrect BOOLEAN,
    CONSTRAINT fk_questionAnswer FOREIGN KEY (QuestionID) REFERENCES Question(QuestionNumberAwnser)
);
