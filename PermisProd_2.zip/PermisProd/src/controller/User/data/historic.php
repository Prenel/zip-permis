<?php  ob_start(); 
require '../../../../config/conf_header.php';
require '../../../../src/view/component/header.php';
require_once '../../../../config/config.php';
require '../log/checkAuth.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
} else {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        header("Location: historic.php?user_id=" . $user_id);
        exit();
    } else {
        header("Location: login.php");
        exit();
    }
}


$query = "
    SELECT t.id AS test_id, t.score, t.validate, t.passDate
    FROM test t
    WHERE t.user_id = $1
    ORDER BY t.id DESC
";


$query_user_stats = "
    SELECT 
        COUNT(*) FILTER (WHERE validate = 't' AND score >= 80) AS validated,
        COUNT(*) FILTER (WHERE validate = 'f' OR score < 80) AS not_validated
    FROM test
    WHERE user_id = $1;
";

$result_user_stats = pg_query_params($conn, $query_user_stats, [$user_id]);
if ($result_user_stats) {
    $data_user_stats = pg_fetch_assoc($result_user_stats);
} else {
    die("Erreur lors de la récupération des statistiques de l'utilisateur.");
}

// Récupérer la date du dernier test validé
$query_last_validated = "
    SELECT passDate
    FROM test
    WHERE user_id = $1 AND validate = 't'
    ORDER BY passDate DESC
    LIMIT 1;
";

$result_last_validated = pg_query_params($conn, $query_last_validated, [$user_id]);
if ($result_last_validated) {
    $last_validated = pg_fetch_assoc($result_last_validated);
} else {
    die("Erreur lors de la récupération de la date du dernier test validé.");
}

// Calcul des pourcentages
$total_tests_user = $data_user_stats['validated'] + $data_user_stats['not_validated'];
$avg_user_validated = $total_tests_user > 0 ? ($data_user_stats['validated'] / $total_tests_user * 100) : 0;
$avg_user_not_validated = $total_tests_user > 0 ? ($data_user_stats['not_validated'] / $total_tests_user * 100) : 0;

$result = pg_query_params($conn, $query, array($user_id));
$tests = pg_fetch_all($result);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Historique des Questionnaires</title>
    <link rel="stylesheet" href="historic.css"/>
    <link rel="stylesheet" href="../../../style/main.css"/>
</head>
<body>
    <section class="historic">
        <h1>Historique de vos questionnaires</h1>
        <!-- Section des statistiques de l'utilisateur -->
        <div class="user-stats">
            <h3>Statistiques de vos Questionnaires</h3>
            <div class="stats-info">
                <p>Questionnaires validés : <span class="stat-value"><?= $data_user_stats['validated'] ?></span></p>
                <p>Questionnaires non validés : <span class="stat-value"><?= $data_user_stats['not_validated'] ?></span></p>
                <p>Taux de réussite : <span class="stat-value"><?= round($avg_user_validated, 2) ?>%</span></p>
                <p>Dernier questionnaire validé : 
                    <span class="stat-value">
                        <?php if ($last_validated): ?>
                            <?= htmlspecialchars(date('d M Y, H:i:s', strtotime($last_validated['passdate']))) ?>
                        <?php else: ?>
                            Aucun questionnaire validé pour le moment.
                        <?php endif; ?>
                    </span>
                </p>
            </div>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Date du Questionnaire</th>
                    <th>Score</th>
                    <th>Validation</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($tests): ?>
                    <?php foreach ($tests as $test): ?>
                        <tr>
                            <td><?php echo htmlspecialchars(date('d M Y, H:i:s', strtotime($test['passdate']))); ?></td>
                            <td><?php echo htmlspecialchars($test['score']); ?>/25</td>
                            <td class="<?php echo ($test['validate'] === 't') ? 'valide' : 'non-valide'; ?>">
                                <?php echo ($test['validate'] === 't') ? 'Validé' : 'Non validé'; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">Aucun questionnaire trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <form method="POST" action="send_email.php?user_id=<?php echo $user_id; ?>">
            <button class="button mail-button" type="submit">Envoyer par mail</button>
        </form>
    </section>
</body>
<script>
    // Détecter quand la souris quitte la fenêtre
    document.addEventListener('mouseleave', function() {
        document.body.classList.add('screenshot-blocked');
    });

    // Détecter quand la souris revient sur la fenêtre
    document.addEventListener('mouseenter', function() {
        document.body.classList.remove('screenshot-blocked');
    });
    document.addEventListener('keydown', (event) => {
    
        // Détecter la touche Impr écran (PrtScn)
    if (event.key === 'PrintScreen' || (event.ctrlKey && event.key === 'p')) {
        event.preventDefault();
        alert('Les captures d\'écran sont désactivées sur ce site.');
    }
    });

    document.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    alert('Le clic droit est désactivé sur ce site.');
    });

    document.addEventListener('copy', (event) => {
    event.preventDefault();
    alert('Le copier est désactivé sur ce site.');
    });

    document.addEventListener('cut', (event) => {
        event.preventDefault();
        alert('Le couper est désactivé sur ce site.');
    });

    document.addEventListener('paste', (event) => {
        event.preventDefault();
        alert('Le coller est désactivé sur ce site.');
    });

    document.addEventListener('keydown', (event) => {
        // Détecter Ctrl + S (ou Cmd + S sur Mac)
        if ((event.ctrlKey || event.metaKey) && event.key === 's') {
            event.preventDefault();
            alert('L\'enregistrement de la page est désactivé.');
        }
    });

    // Détecter l'ouverture des outils de développement
    let devToolsOpened = false;

    setInterval(() => {
        const widthThreshold = window.outerWidth - window.innerWidth > 160;
        const heightThreshold = window.outerHeight - window.innerHeight > 160;

        if ((widthThreshold || heightThreshold) && !devToolsOpened) {
            devToolsOpened = true;
            alert('Les outils de développement sont désactivés.');
            window.location.reload(); // Recharger la page
        }
    }, 1000);

    // Intercepter F12, Ctrl + Shift + I, Ctrl + Shift + C
    document.addEventListener('keydown', (event) => {
        if (
            event.key === 'F12' ||
            (event.ctrlKey && event.shiftKey && event.key === 'I') ||
            (event.ctrlKey && event.shiftKey && event.key === 'C')
        ) {
            event.preventDefault();
            alert('Les outils de développement sont désactivés.');
        }
    });
</script>
</html>

<?php require '../../../../src/view/component/footer.php'; ?>
<?php require '../../../../config/conf_footer.php'; ?>
