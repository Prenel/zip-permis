<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<section class="header-section">
    <div class="header">
        <div>
            <a href="../../../../index.php" class="header-lien logo-header" title="Page d'Accueil">
                <img src="../../../../../public/src/images/CA_Logo_seul-1.svg" alt="Logo CA" class="logo-image">
            </a>
        </div>
        <div><a href="../../../../../index.php" class="header-lien" title="Page d'Accueil">CA-GIP Permis de Production</a></div>

        <div>
            <?php if (isset($_SESSION['username'])): ?>
                <a href="../../../../../src/controller/User/profil/user.php" class="header-lien-user" title="Page Utilisateur"><?php echo htmlspecialchars($_SESSION['username']); ?></a>
            <?php else: ?>
                <a href="../../../../../src/controller/User/profil/user.php" class="header-lien-user" title="Page de connexion">Login</a>
            <?php endif; ?>
        </div>
    </div>
</section>
