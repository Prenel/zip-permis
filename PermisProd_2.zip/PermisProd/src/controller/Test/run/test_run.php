<?php 
ob_start();
session_start();

require_once '../../../../config/config.php';
require '../../User/log/checkAuth.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


$session_id = session_id(); 


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id  = $_SESSION['user_id'];
    $username = $_SESSION['username'];
    $email    = $_SESSION['manager'];

    // Lancer l'envoi de l'email via send_email.php sans interrompre le reste du code
    $url = "https://cagip.edbackend.eu/src/controller/User/data/send_email.php?user_id=" . urlencode(string: $user_id) . "&manager=true"; // Changer pour url du site

    // Appel asynchrone avec curl
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 1); // On réduit le temps d'attente pour rendre l'appel asynchrone
    curl_setopt($ch, CURLOPT_HEADER, 0);
    // Transmettre l'ID de session en tant que cookie
    curl_setopt($ch, CURLOPT_COOKIE, "PHPSESSID=$session_id");

    $response = curl_exec($ch);

    curl_close($ch);

    $user_answers = json_decode($_POST['answers'], true);

    if (!is_array($user_answers)) {
        echo "Erreur : Les réponses ne sont pas valides.";
        exit;
    }

    $total_questions = count($user_answers);
    $score = 0;

    foreach ($user_answers as $question_id => $user_choices) {
        $query = "SELECT answer_text FROM answer WHERE question_id = $1 AND is_correct = TRUE";
        $result = pg_query_params($conn, $query, array($question_id));

        if ($result && pg_num_rows($result) > 0) {
            $correct_answers = pg_fetch_all_columns($result);

            $all_correct_selected = !array_diff($correct_answers, $user_choices);
            $no_incorrect_selected = !array_diff($user_choices, $correct_answers);

            if ($all_correct_selected && $no_incorrect_selected) {
                $score++;
            }
        }/*  else {
            echo "Erreur : question ou réponse non trouvée dans la base de données.<br>";
        } */
    }

    $percentage = ($score / $total_questions) * 100;

    $validate = ($percentage >= 80) ? 't' : 'f';
    
    if ($validate === 't') {
        $validationState = 'TRUE';
        $update_query = "UPDATE users SET validationState = $1, validationDate = CURRENT_TIMESTAMP, validationExpirationDate = CURRENT_TIMESTAMP + INTERVAL '30 days' WHERE id = $2";
        $update_result = pg_query_params($conn, $update_query, array($validationState, $user_id));
    
        if (!$update_result) {
            echo "Erreur lors de la mise à jour de l'état de validation.<br>";
            echo pg_last_error($conn);
            exit;
        }
    } else {
        $validationState = 'FALSE';
    
        $update_query = "UPDATE users SET validationState = $1 WHERE id = $2";
        $update_result = pg_query_params($conn, $update_query, array($validationState, $user_id));
    
        if (!$update_result) {
            echo "Erreur lors de la mise à jour de l'état de validation.<br>";
            echo pg_last_error($conn);
            exit;
        }
    }

    $query = "INSERT INTO test (user_id, score, validate, passDate) VALUES ($1, $2, $3, CURRENT_TIMESTAMP)";
    $result = pg_query_params($conn, $query, array($user_id, $score, $validate));

    if (!$result) {
        echo "Erreur lors de l'insertion du test.<br>";
        echo pg_last_error($conn);
        exit;
    }

    unset($_SESSION['test_in_progress']);
    unset($_SESSION['questions']);
    echo "<div style='text-align: center; margin-top: 50px; font-family: \"Latinaka\", sans-serif;'>";
    echo "<h3 style='font-size: 4rem; color: #071621;'>Votre questionnaire est terminé !</h3>";
    echo "<p style='font-size: 2rem; color: #071621;'>Votre score est de $score/$total_questions.</p>";
    if ($validate === 't') {
        echo "<p style='font-size: 2rem; color: green;'>Questionnaire validé ! Félicitations, vous avez dépassé 80%.</p>";
        echo "<p><a href='../../User/data/historic.php' title='Page Historique' style='background-color: #308276; color: white; padding: 10px 20px; border-radius: 5px; font-size: 2rem; text-decoration: none;'>Accéder à l'historique de vos tests</a></p>";
    } else {
        echo "<p style='font-size: 2rem; color: red;'>Questionnaire non validé. Vous avez besoin de plus de 80% pour valider.</p>";
        echo "<p><a href='../../User/data/historic.php' title='Page Historique' style='background-color: #308276; color: white; padding: 10px 20px;font-size: 2rem; border-radius: 5px; text-decoration: none;'>Accéder à l'historique de vos questionnaires</a></p>";
    }
    echo "</div>";
    exit;
}

if (!isset($_SESSION['test_in_progress'])) {
    echo "<div style='text-align: center; margin-top: 100px; font-family: \"Latinaka\", sans-serif;'>";
    echo "<h3 style='font-size: 4rem; color: #071621;'>Aucun questionnaire en cours</h3>";
    echo "<p style='font-size: 2rem;'>Veuillez démarrer un questionnaire depuis la page de questionnaire.</p>";
    echo "<a href='../presentation/test.php' title='Page de présentation du test' style='background-color: #308276; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-size: 2em; margin-top: 20px; display: inline-block;'>Retour à la page de démarrage du questionnaire</a>";
    echo "</div>";
    exit;
}

if (!isset($_SESSION['questions'])) {
    $query = "
        WITH prod_first_questions AS (
            SELECT 
                questions.id AS question_id, 
                questions.theme_id, 
                questions.question, 
                theme.theme_name
            FROM questions
            JOIN theme ON questions.theme_id = theme.id
            WHERE theme.theme_name = 'ProdFirst'
            ORDER BY RANDOM()
            LIMIT 15 /* 15 */
        ),
        other_questions AS (
            SELECT 
                questions.id AS question_id, 
                questions.theme_id, 
                questions.question, 
                theme.theme_name
            FROM questions
            JOIN theme ON questions.theme_id = theme.id
            WHERE theme.theme_name != 'ProdFirst'
            ORDER BY RANDOM()
            LIMIT 10 /* 10 */
        )
        SELECT *
        FROM (
            SELECT * FROM prod_first_questions
            UNION ALL
            SELECT * FROM other_questions
        ) AS combined_questions
        ORDER BY RANDOM();
    ";

    $result = pg_query($conn, $query);

    if ($result) {
        $questions = pg_fetch_all($result);
        $_SESSION['questions'] = $questions;
    } else {
        echo "Erreur lors de la récupération des questions.<br>";
        echo pg_last_error($conn);
        exit;
    }
}


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link rel="stylesheet" href="test_run.css"/>
    <link rel="stylesheet" href="../../../style/main.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <meta charset="UTF-8">
    <title>Permis de production CA-GIP en cours</title>
</head>
<body>
    <div class="qcm-container">
        <h1>Permis de production CA-GIP</h1>
        <div id="progress-info">
            <p id="question-progress">Question 1 sur 25</span></p> <!-- <span id="total-questions"> -->
            <p id="theme-name">Thème : <font color='#308276'><b><span id="theme-text"></span></b></font> <span id="theme-id" style="display: none;"></span></p>
        </div>

        <div class="question-container">
            <h2 id="question-title"></h2>
            <ul id="answers-list" class="answers"></ul>
        </div>

        <!-- Ajout du champ commentaire ici -->
<!--         <div class="comment-container">
            <label for="comment" class="comment-title">Commentaire :</label>
            <textarea id="comment" name="comment" maxlength="250" rows="4" cols="40" placeholder="Ajouter un commentaire"></textarea>
            <p id="char-counter">250 caractères restants</p>
        </div> -->

        <div class="navigation-buttons">
            <button type="button" id="prev-btn" onclick="prevQuestion()">Précédent</button>
            <button type="button" id="next-btn" onclick="nextQuestion()">Suivant</button>
        </div>
        <form method="post" action="test_run.php" id="qcm-form">
            <input type="hidden" name="answers" id="answers-input">
            <input type="hidden" name="comment" id="comment-input">
        </form>

    </div>
    <script>
        // Détecter quand la souris quitte la fenêtre
        document.addEventListener('mouseleave', function() {
            document.body.classList.add('screenshot-blocked');
        });

        // Détecter quand la souris revient sur la fenêtre
        document.addEventListener('mouseenter', function() {
            document.body.classList.remove('screenshot-blocked');
        });
        document.addEventListener('keydown', (event) => {
        
            // Détecter la touche Impr écran (PrtScn)
        if (event.key === 'PrintScreen' || (event.ctrlKey && event.key === 'p')) {
            event.preventDefault();
            alert('Les captures d\'écran sont désactivées sur ce site.');
        }
        });

        document.addEventListener('contextmenu', (event) => {
        event.preventDefault();
        alert('Le clic droit est désactivé sur ce site.');
        });

        document.addEventListener('copy', (event) => {
        event.preventDefault();
        alert('Le copier est désactivé sur ce site.');
        });

        document.addEventListener('cut', (event) => {
            event.preventDefault();
            alert('Le couper est désactivé sur ce site.');
        });

        document.addEventListener('paste', (event) => {
            event.preventDefault();
            alert('Le coller est désactivé sur ce site.');
        });

        document.addEventListener('keydown', (event) => {
            // Détecter Ctrl + S (ou Cmd + S sur Mac)
            if ((event.ctrlKey || event.metaKey) && event.key === 's') {
                event.preventDefault();
                alert('L\'enregistrement de la page est désactivé.');
            }
        });

        // Détecter l'ouverture des outils de développement
        let devToolsOpened = false;

        setInterval(() => {
            const widthThreshold = window.outerWidth - window.innerWidth > 160;
            const heightThreshold = window.outerHeight - window.innerHeight > 160;

            if ((widthThreshold || heightThreshold) && !devToolsOpened) {
                devToolsOpened = true;
                alert('Les outils de développement sont désactivés.');
                window.location.reload(); // Recharger la page
            }
        }, 1000);

        // Intercepter F12, Ctrl + Shift + I, Ctrl + Shift + C
        document.addEventListener('keydown', (event) => {
            if (
                event.key === 'F12' ||
                (event.ctrlKey && event.shiftKey && event.key === 'I') ||
                (event.ctrlKey && event.shiftKey && event.key === 'C')
            ) {
                event.preventDefault();
                alert('Les outils de développement sont désactivés.');
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
/*         const commentTextarea = document.getElementById('comment');
        const charCounter = document.getElementById('char-counter');

        commentTextarea.addEventListener('input', () => {
            const remaining = 250 - commentTextarea.value.length;
            charCounter.textContent = `${remaining} caractères restants`;
        }); */


        const questions = <?php echo json_encode($questions); ?>; // Récupère les questions côté serveur
        let currentQuestionIndex = 0; // Index de la question actuelle
        const userAnswers = {}; // Stocke les réponses utilisateur

        let timer; // Référence pour le chrono
        let timeLeft = 45; // Temps en secondes

        // Fonction pour démarrer le chrono
        function startTimer() {
            const timerDisplay = document.getElementById('timer');
            timeLeft = 45; // Réinitialise le temps

            timer = setInterval(() => {
                timeLeft--;
                timerDisplay.textContent = `Temps restant : ${timeLeft} secondes`;

                if (timeLeft <= 0) {
                    clearInterval(timer);
                    handleTimeout(); // Gère la fin du temps
                }
            }, 1000);
        }

        // Fonction pour gérer la fin du temps
        function handleTimeout() {
            saveCurrentAnswers(); // Sauvegarde les réponses actuelles (si aucune réponse, l'utilisateur obtient faux)
            nextQuestion(); // Passe à la question suivante
        }

        // Fonction pour charger une question
        function loadQuestion(index) {
            clearInterval(timer); // Arrête le chrono précédent
            startTimer(); // Redémarre un nouveau chrono

            const questionTitle = document.getElementById('question-title');
            const answersList = document.getElementById('answers-list');
            const progressInfo = document.getElementById('question-progress');
            const themeText = document.getElementById('theme-text');
            const themeId = document.getElementById('theme-id');

            // Vérifie si l'index est valide
            if (index < 0 || index >= questions.length) {
                console.error("Index de question invalide :", index);
                return;
            }

            // Met à jour les informations de la progression
            progressInfo.textContent = `Question ${index + 1} sur ${questions.length}`;
            themeText.textContent = questions[index].theme_name || 'Non défini';
            themeId.textContent = questions[index].theme_id || 'ID non défini';

            // Affiche la question actuelle
            questionTitle.textContent = questions[index].question;
            answersList.innerHTML = '';

            const questionId = questions[index].question_id;

            // Récupère les réponses de la question
            fetch(`get_answers.php?question_id=${questionId}`)
                .then(response => response.json())
                .then(data => {
                    data.forEach((answer, i) => {
                        const li = document.createElement('li');
                        li.innerHTML = `
                            <input type="checkbox" name="answer" id="answer${i}" value="${answer.answer_text}" 
                                ${userAnswers[questionId] && userAnswers[questionId].includes(answer.answer_text) ? 'checked' : ''}>
                            <label for="answer${i}">${answer.answer_text}</label>
                        `;
                        answersList.appendChild(li);
                    });

                    // Ajoute un écouteur d'événement pour afficher le bouton "Suivant" dès qu'une réponse est cochée
                    const checkboxes = document.querySelectorAll('input[name="answer"]');
                    checkboxes.forEach((checkbox) => {
                        checkbox.addEventListener('change', updateButtonState);
                    });

                    updateButtonState();
                })
                .catch(error => console.error("Erreur lors du chargement des réponses :", error));
        }

        // Met à jour l'état des boutons navigationnels
        function updateButtonState() {
            const nextBtn = document.getElementById('next-btn');
            const prevBtn = document.getElementById('prev-btn');
            const selectedAnswers = document.querySelectorAll('input[name="answer"]:checked');

            // Gère l'état du bouton "Précédent"
            prevBtn.disabled = currentQuestionIndex === 0;

            // Gère l'état du bouton "Suivant" : visible si une réponse est sélectionnée
            nextBtn.style.visibility = selectedAnswers.length > 0 ? 'visible' : 'hidden';

            if (currentQuestionIndex === questions.length - 1) {
                nextBtn.textContent = 'Valider';
                nextBtn.setAttribute('onclick', "submitForm()");
            } else {
                nextBtn.textContent = 'Suivant';
                nextBtn.setAttribute('onclick', 'nextQuestion()');
            }
        }

        // Navigation : Bouton "Précédent"
        function prevQuestion() {
            if (currentQuestionIndex > 0) {
                saveCurrentAnswers(); // Sauvegarde les réponses actuelles
                currentQuestionIndex--;
                loadQuestion(currentQuestionIndex); // Charge la question précédente
            }
        }

        // Navigation : Bouton "Suivant"
        function saveCurrentIndex() {
            localStorage.setItem('currentQuestionIndex', currentQuestionIndex);
        }

        // Navigation : Bouton "Précédent"
        function prevQuestion() {
            clearInterval(timer); // Arrête le chrono actuel
            if (currentQuestionIndex > 0) {
                saveCurrentAnswers();
                currentQuestionIndex--;
                saveCurrentIndex();
                loadQuestion(currentQuestionIndex);
            }
        }

        // Navigation : Bouton "Suivant"
        function nextQuestion() {
            clearInterval(timer); // Arrête le chrono actuel
            if (currentQuestionIndex < questions.length - 1) {
                saveCurrentAnswers();
                currentQuestionIndex++;
                saveCurrentIndex();
                loadQuestion(currentQuestionIndex);
            } else {
                submitForm(); // Soumet le formulaire si c'est la dernière question
            }
        }

        // Enregistre les réponses actuelles de l'utilisateur
        function saveCurrentAnswers() {
            const questionId = questions[currentQuestionIndex].question_id;
            const checkboxes = document.querySelectorAll('input[name="answer"]:checked');
            userAnswers[questionId] = Array.from(checkboxes).map(cb => cb.value);
        }

        // Envoie un commentaire au serveur via AJAX
        function insertCommentIntoDB(comment, themeText, idquestion) {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'insert_comment.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

            xhr.send(`comment=${encodeURIComponent(comment)}&themetext=${encodeURIComponent(themeText)}&idquestion=${encodeURIComponent(idquestion)}`);

            xhr.onload = function () {
                if (xhr.status === 200) {
                    console.log('Commentaire inséré avec succès :', xhr.responseText);
                } else {
                    console.error('Erreur lors de l\'insertion du commentaire :', xhr.statusText);
                }
            };
        }

        // Soumet le formulaire final
        function submitForm() {
            saveCurrentAnswers(); // Sauvegarde les réponses finales
            document.getElementById('answers-input').value = JSON.stringify(userAnswers); // Prépare les réponses pour l'envoi
            localStorage.removeItem('currentQuestionIndex'); // Supprime l'index sauvegardé
            document.getElementById('qcm-form').submit(); // Soumet le formulaire
        }


        // Initialiser l'état du bouton "Suivant" comme caché lors du chargement de la page
        // Ajouter l'affichage du chrono dans le HTML
        window.onload = function () {
            const savedIndex = localStorage.getItem('currentQuestionIndex');
            currentQuestionIndex = savedIndex && !isNaN(savedIndex) ? parseInt(savedIndex, 10) : 0;

            // Ajouter un conteneur pour le chrono
            const progressInfo = document.getElementById('progress-info');
            let timerElement = document.getElementById('timer');
            if (!timerElement) {
                timerElement = document.createElement('p');
                timerElement.id = 'timer';
                timerElement.textContent = `Temps restant : 45 secondes`;
                progressInfo.appendChild(timerElement);
            }

            loadQuestion(currentQuestionIndex); // Charge la première question
            startTimer(); // Démarre le chrono
        };


    </script>
</body>
</html>