-- Table des thèmes
CREATE TABLE theme (
    id SERIAL PRIMARY KEY,      
    theme_name TEXT NOT NULL       
);

-- Table des questions
CREATE TABLE questions (
    id SERIAL PRIMARY KEY,     
    question TEXT NOT NULL,      
    theme_id INTEGER NOT NULL,   
    CONSTRAINT fk_themeQuestions FOREIGN KEY (theme_id) REFERENCES theme(id) 
);

-- Table des réponses
CREATE TABLE answer (
    id SERIAL PRIMARY KEY,          
    question_id INTEGER NOT NULL, 
    answer_text TEXT NOT NULL,   -- Texte de la réponse
    is_correct BOOLEAN NOT NULL,  -- Indique si la réponse est correcte ou non
    CONSTRAINT fk_questionAnswer FOREIGN KEY (question_id) REFERENCES questions(id)  
);

-- Table des utilisateurs
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username TEXT NOT NULL,           
    mail TEXT NOT NULL UNIQUE,          
    pass TEXT NOT NULL,           
    firstName TEXT NOT NULL,           
    lastName TEXT NOT NULL,
    cluster TEXT NOT NULL, -- (CXI, CIB, BPC, BPCR, GEA, Paiements, SFS)
    validationState BOOLEAN NOT NULL,
    validationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    validationExpirationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    manager TEXT NOT NULL,
    team CHARACTER VARYING(16),
    isadmin BOOLEAN NOT NULL DEFAULT FALSE,
);

-- Table des managers
CREATE TABLE managers(
    id SERIAL PRIMARY KEY, 
    managerFirstName TEXT NOT NULL,  
    managerLastName TEXT NOT NULL,
    managerMail TEXT NOT NULL
);

-- Table de liaison entre utilisateurs et managers (Many-to-Many)
CREATE TABLE user_managers (
    user_id INTEGER NOT NULL,
    manager_id INTEGER NOT NULL,
    CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_manager FOREIGN KEY (manager_id) REFERENCES managers(id),
    PRIMARY KEY (user_id, manager_id)
);

-- Table des tests
CREATE TABLE test (
    id SERIAL PRIMARY KEY, 
    user_id INTEGER NOT NULL, 
    score INTEGER NOT NULL,
    validate BOOLEAN NOT NULL,
    passDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    CONSTRAINT fk_userTest FOREIGN KEY (user_id) REFERENCES users(id)
);
