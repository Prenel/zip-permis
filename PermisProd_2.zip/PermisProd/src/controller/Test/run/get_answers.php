<?php require_once '../../../../config/config.php';

if (isset($_GET['question_id'])) {
    $question_id = $_GET['question_id'];

    $query = "SELECT * FROM answer WHERE question_id = $1";
    $result = pg_query_params($conn, $query, array($question_id));
    $answers = pg_fetch_all($result);

    echo json_encode($answers);
}
?>
