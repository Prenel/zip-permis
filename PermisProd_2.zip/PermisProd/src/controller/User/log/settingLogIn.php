<?php ob_start();
session_start();
require_once '../../../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validation de l'email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Adresse e-mail non valide.";
        header('Location: login.php');
        exit;
    }

    // Requête pour récupérer l'utilisateur
    $query = "SELECT * FROM users WHERE mail = $1";
    $result = pg_query_params($conn, $query, array($email));

    if (!$result) {
        die("Erreur dans la requête SQL : " . pg_last_error($conn));
    }

    if ($row = pg_fetch_assoc($result)) {
        // Vérification du mot de passe
        if ($password === $row['pass']) {
            // Capture des données utilisateur dans la session
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['email'] = $row['mail'];
            $_SESSION['username'] = $row['username'];

            // Conversion des champs isadmin et validationstate en booléens
            $_SESSION['isadmin'] = ($row['isadmin'] == 't');
            $_SESSION['validationState'] = $row['validationstate'] == 't';

            $_SESSION['manager'] = $row['manager'];

            // Génération d'un token sécurisé
            $_SESSION['token'] = bin2hex(random_bytes(32));

            header('Location: ../../../../index.php');
            exit;
        } else {
            // Mot de passe incorrect
            $_SESSION['error'] = "Mot de passe incorrect.";
            header('Location: login.php');
            exit;
        }
    } else {
        // Utilisateur non trouvé
        $_SESSION['error'] = "Utilisateur non trouvé.";
        header('Location: login.php');
        exit;
    }
}
