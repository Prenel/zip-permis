<?php
session_start();
ob_start();

require 'config/conf_header.php';
require 'src/view/component/header.php';
require 'src/controller/User/log/checkAuth.php';

?>

<head>
    <title>CA-GIP Permis de Production</title>
    <link rel="stylesheet" href="src/style/main.css"/>
</head>

<section class="accueil">
    <div class="accueil-title">
        <h1>Bienvenue <?= htmlspecialchars($_SESSION['username'] ?? 'Utilisateur') ?></h1>
    </div>
    <div class="accueil-presentation">
        <div class="accueil-presentation-title">
            <h1>Questionnaire de Certification CA-GIP Permis de Production</h1>
        </div>
        <div class="accueil-presentation-text">
            <div class="texte">
                Vous allez passer un questionnaire de certification CA-GIP Permis de Production.
            </div>
            <br>
        </div>
    </div>
    <div>
        <a href="src/controller/Test/presentation/crise.php">
            <button title="Effectuer le test Pilotage d'une crise" class="button accueil-button">Pilotage d'une crise</button>
        </a>
    </div>
    <div>
        <a href="src/controller/Test/presentation/new.php">
            <button title="Effectuer le test Nouvel Arrivant" class="button accueil-button">  Nouvel Arrivant  </button>
        </a>
    </div>
    <div>
        <a href="src/controller/Test/presentation/test.php">
            <button title="Effectuer le test Prod First" class="button accueil-button">     Prod First    </button>
        </a>
    </div>
</section>
<script>
    // Détecter quand la souris quitte la fenêtre
    document.addEventListener('mouseleave', function() {
        document.body.classList.add('screenshot-blocked');
    });

    // Détecter quand la souris revient sur la fenêtre
    document.addEventListener('mouseenter', function() {
        document.body.classList.remove('screenshot-blocked');
    });
    document.addEventListener('keydown', (event) => {
    
        // Détecter la touche Impr écran (PrtScn)
    if (event.key === 'PrintScreen' || (event.ctrlKey && event.key === 'p')) {
        event.preventDefault();
        alert('Les captures d\'écran sont désactivées sur ce site.');
    }
    });

    document.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    alert('Le clic droit est désactivé sur ce site.');
    });

    document.addEventListener('copy', (event) => {
    event.preventDefault();
    alert('Le copier est désactivé sur ce site.');
    });

    document.addEventListener('cut', (event) => {
        event.preventDefault();
        alert('Le couper est désactivé sur ce site.');
    });

    document.addEventListener('paste', (event) => {
        event.preventDefault();
        alert('Le coller est désactivé sur ce site.');
    });

    document.addEventListener('keydown', (event) => {
        // Détecter Ctrl + S (ou Cmd + S sur Mac)
        if ((event.ctrlKey || event.metaKey) && event.key === 's') {
            event.preventDefault();
            alert('L\'enregistrement de la page est désactivé.');
        }
    });

    // Détecter l'ouverture des outils de développement
    let devToolsOpened = false;

    setInterval(() => {
        const widthThreshold = window.outerWidth - window.innerWidth > 160;
        const heightThreshold = window.outerHeight - window.innerHeight > 160;

        if ((widthThreshold || heightThreshold) && !devToolsOpened) {
            devToolsOpened = true;
            alert('Les outils de développement sont désactivés.');
            window.location.reload(); // Recharger la page
        }
    }, 1000);

    // Intercepter F12, Ctrl + Shift + I, Ctrl + Shift + C
    document.addEventListener('keydown', (event) => {
        if (
            event.key === 'F12' ||
            (event.ctrlKey && event.shiftKey && event.key === 'I') ||
            (event.ctrlKey && event.shiftKey && event.key === 'C')
        ) {
            event.preventDefault();
            alert('Les outils de développement sont désactivés.');
        }
    });
</script>

<?php require 'src/view/component/footer.php' ?>
<?php require 'config/conf_footer.php' ?>
