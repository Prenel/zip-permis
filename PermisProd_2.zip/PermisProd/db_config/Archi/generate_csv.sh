#chmod +x generate_csv.sh
#./generate_csv.sh
#!/bin/bash

# Dossiers et fichiers
input_folder="./input_files"
output_questions="questions.csv"
output_reponses="reponses.csv"

# En-têtes des fichiers de sortie
echo "Id,Numero,Theme,IdTheme,SubTheme,Question,QuestionNumberAwnser" > $output_questions
echo "Id,QuestionID,Reponse,ReponseCorrect" > $output_reponses

# Variables pour incrémentation
question_id=1
response_id=1
id_theme=1

# Parcours des fichiers CSV dans le dossier input_files
for file in $input_folder/*.csv; do
    # Récupération du thème depuis le nom du fichier (nom du fichier sans extension)
    theme=$(basename "$file" .csv)

    # Lecture ligne par ligne du fichier d'entrée
    while IFS=',' read -r numero question reponse1 reponse2 reponse3 reponse4 bonne_reponse; do
        # Sauter les en-têtes
        if [[ $numero == "Numéro" || $numero == "" ]]; then
            continue
        fi

        # Nettoyage des réponses pour gérer les guillemets ou espaces supplémentaires
        reponse1=$(echo "$reponse1" | sed 's/^"//;s/"$//')
        reponse2=$(echo "$reponse2" | sed 's/^"//;s/"$//')
        reponse3=$(echo "$reponse3" | sed 's/^"//;s/"$//')
        reponse4=$(echo "$reponse4" | sed 's/^"//;s/"$//')

        # Ajout dans le fichier questions.csv
        echo "$question_id,$numero,$theme,$id_theme,,\"$question\",$bonne_reponse" >> $output_questions

        # Liste des réponses
        reponses=("$reponse1" "$reponse2" "$reponse3" "$reponse4")

        # Traitement des réponses
        for i in "${!reponses[@]}"; do
            response_text="${reponses[$i]}"
            
            # Ignorer les réponses vides
            if [[ -z "$response_text" ]]; then
                continue
            fi

            # Vérifier si cette réponse est correcte
            if [[ $((i + 1)) -eq $bonne_reponse ]]; then
                correct=true
            else
                correct=false
            fi

            # Ajout dans le fichier reponses.csv avec protection des caractères spéciaux
            echo "$response_id,$question_id,\"$response_text\",$correct" >> $output_reponses

            # Incrémenter l'ID des réponses
            response_id=$((response_id + 1))
        done

        # Incrémenter l'ID des questions
        question_id=$((question_id + 1))
    done < "$file"

    # Incrémenter l'ID du thème
    id_theme=$((id_theme + 1))
done

echo "Génération des fichiers CSV terminée : $output_questions et $output_reponses"
