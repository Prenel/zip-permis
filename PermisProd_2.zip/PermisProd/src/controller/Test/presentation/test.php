<?php ob_start(); session_start();

require '../../../../config/conf_header.php';
require '../../../../src/view/component/header.php';
require '../../../controller/User/log/checkAuth.php';



if (isset($_POST['stop_test'])) {
    $user_id = $_SESSION['user_id'];

    if (isset($_SESSION['questions'])) {
        foreach ($_SESSION['questions'] as $question_id) {
            $query = "INSERT INTO historic (user_id, question_id, choice, good) VALUES ($1, $2, NULL, 0)";
            pg_query_params($conn, $query, array($user_id, $question_id));
        }
    }

    unset($_SESSION['test_in_progress']);
    unset($_SESSION['questions']);

    header('Location: test.php');
    exit;
}
if (isset($_SESSION['test_in_progress'])) {
    echo "<div class='testError' style='margin-top: 100px; text-align: center; font-family: Latinaka, sans-serif;'>";
    echo "<h2 style='font-family: Latinaka, sans-serif;'>Questionnaire déjà en cours</h2>";
    echo "<p style='font-family: Latinaka, sans-serif;'>Un questionnaire est déjà en cours. Veuillez le stopper pour pouvoir en commencer un autre.</p>";
    echo '<form method="post" action="test.php" style="margin-top: 20px;" onsubmit="clearLocalStorage()">
            <button class="button stop-button" title="Stopper le Test" type="submit" name="stop_test" style="font-family: Latinaka, sans-serif; font-size:25px;">Stopper le Questionnaire</button>
          </form>';
    echo "</div>";
    echo "<script>
            function clearLocalStorage() {
                localStorage.removeItem('currentQuestionIndex');
            }
          </script>";
    exit;
}



if (isset($_POST['start_test'])) {
    $_SESSION['test_in_progress'] = true;
    header('Location: ../run/test_run.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head> 
    <meta charset="UTF-8">
    <link rel="stylesheet" href="test.css"/>
    <link rel="stylesheet" href="../../../style/main.css"/>
    <title>Démarrer Permis de production CA-GIP</title> 
</head>
<body>
    <div class="test">
        <div class="test-title">
            <h1>Présentation du Questionnaire</h1>
        </div>        
        <div class="test-presentation">
            <p class="test-presentation-texte">
                Ce questionnaire comporte <strong>25 questions</strong> réparties sur <strong>5 thèmes fondamentaux</strong> :
                Prod First, Client, One Team, Risk and Security, Gouvernance.
                Vous avez <strong>45 secondes</strong> par question.
            </p>

            <h2>Règles importantes :</h2>
            <ul>
                <li>Une fois le quiz commencé, vous <strong>ne pouvez pas reprendre</strong> où vous vous êtes arrêté en cas d’interruption.</li>
                <li>Si vous devez arrêter pour une raison quelconque, vous devrez <strong>recommencer le questionnaire</strong> depuis le début.</li>
            </ul>
            <br>
            <p class="test-presentation-warning">
                Assurez-vous donc d’être prêt avant de commencer !
            </p>
        </div>
        <div class="test-help">
            <p>Cliquez sur le bouton ci-dessous pour démarrer un test.</p>
        </div>
        <div>
            <form method="post" action="test.php">
                <button type="submit" title="Commencer le test" class="button test-button" name="start_test">On y va !</button>
            </form>
        </div>
    </div>
    <script>
        // Détecter quand la souris quitte la fenêtre
        document.addEventListener('mouseleave', function() {
            document.body.classList.add('screenshot-blocked');
        });

        // Détecter quand la souris revient sur la fenêtre
        document.addEventListener('mouseenter', function() {
            document.body.classList.remove('screenshot-blocked');
        });
        document.addEventListener('keydown', (event) => {
        
            // Détecter la touche Impr écran (PrtScn)
        if (event.key === 'PrintScreen' || (event.ctrlKey && event.key === 'p')) {
            event.preventDefault();
            alert('Les captures d\'écran sont désactivées sur ce site.');
        }
        });

        document.addEventListener('contextmenu', (event) => {
        event.preventDefault();
        alert('Le clic droit est désactivé sur ce site.');
        });

        document.addEventListener('copy', (event) => {
        event.preventDefault();
        alert('Le copier est désactivé sur ce site.');
        });

        document.addEventListener('cut', (event) => {
            event.preventDefault();
            alert('Le couper est désactivé sur ce site.');
        });

        document.addEventListener('paste', (event) => {
            event.preventDefault();
            alert('Le coller est désactivé sur ce site.');
        });

        document.addEventListener('keydown', (event) => {
            // Détecter Ctrl + S (ou Cmd + S sur Mac)
            if ((event.ctrlKey || event.metaKey) && event.key === 's') {
                event.preventDefault();
                alert('L\'enregistrement de la page est désactivé.');
            }
        });

        // Détecter l'ouverture des outils de développement
        let devToolsOpened = false;

        setInterval(() => {
            const widthThreshold = window.outerWidth - window.innerWidth > 160;
            const heightThreshold = window.outerHeight - window.innerHeight > 160;

            if ((widthThreshold || heightThreshold) && !devToolsOpened) {
                devToolsOpened = true;
                alert('Les outils de développement sont désactivés.');
                window.location.reload(); // Recharger la page
            }
        }, 1000);

        // Intercepter F12, Ctrl + Shift + I, Ctrl + Shift + C
        document.addEventListener('keydown', (event) => {
            if (
                event.key === 'F12' ||
                (event.ctrlKey && event.shiftKey && event.key === 'I') ||
                (event.ctrlKey && event.shiftKey && event.key === 'C')
            ) {
                event.preventDefault();
                alert('Les outils de développement sont désactivés.');
            }
        });
    </script>
</body>
</html>

<?php
require '../../../../src/view/component/footer.php';
require '../../../../config/conf_footer.php';
?>
