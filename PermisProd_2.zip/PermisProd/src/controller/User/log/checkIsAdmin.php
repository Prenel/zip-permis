<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Initialise la session
}

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION['user_id'], $_SESSION['token'])) {
    header('Location: ../../src/controller/User/log/login.php');
    exit;
}

// Vérifie si l'utilisateur est admin
if (!isset($_SESSION['isadmin']) || !$_SESSION['isadmin']) {
    $_SESSION['error'] = "Accès refusé : vous n'êtes pas administrateur.";
    header('Location: ../../../../index.php');
    exit;
}
