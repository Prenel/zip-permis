<?php
ob_start();
require '../../../../config/conf_header.php';
require '../../../../src/view/component/header.php';
require '../../../controller/User/log/checkIsAdmin.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
function debug_message($message)
{
    echo "<script>console.log(`DEBUG: $message`);</script>";
    echo "<p style='font-family: monospace; color: blue;'>$message</p>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['csv_file']) && isset($_POST['type'])) {
        $type = $_POST['type'];
        $target_dir = "/tmp/";
        $target_file = $target_dir . basename($_FILES['csv_file']['name']);

        debug_message("Début de l'importation pour le type : $type");

        if (pathinfo($target_file, PATHINFO_EXTENSION) !== 'csv') {
            echo "<script>alert('Veuillez déposer un fichier CSV.');</script>";
            debug_message("Le fichier déposé n'est pas au format CSV.");
        } else {
            move_uploaded_file($_FILES['csv_file']['tmp_name'], $target_file);
            debug_message("Fichier uploadé avec succès : $target_file");

            $valid = true;
            $header = [];
            $file = fopen($target_file, "r");
            if ($file !== FALSE) {
                debug_message("Lecture du fichier : $target_file");
                $header = fgetcsv($file);
                debug_message("En-têtes détectées : " . implode(', ', $header));

                if ($type === 'user' && $header !== ['username', 'mail', 'pass', 'firstName', 'lastName', 'cluster', 'validationState', 'validationDate', 'validationExpirationDate', 'manager', 'team', 'isadmin']) {
                    $valid = false;
                    debug_message("En-têtes invalides pour le type 'user'.");
                } elseif ($type === 'manager' && $header !== ['managerFirstName', 'managerLastName', 'managerMail']) {
                    $valid = false;
                    debug_message("En-têtes invalides pour le type 'manager'.");
                } elseif ($type === 'user_manager' && $header !== ['user_id', 'manager_id']) {
                    $valid = false;
                    debug_message("En-têtes invalides pour le type 'user_manager'.");
                }
                fclose($file);
            }

            if ($valid) {
                debug_message("Validation des en-têtes réussie.");
                $file = fopen($target_file, "r");
                fgetcsv($file);

                $insert_query = match ($type) {
                    'user' => 'INSERT INTO users (username, mail, pass, firstname, lastname, cluster, validationstate, validationdate, validationexpirationdate, manager, team, isadmin) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)',
                    'manager' => 'INSERT INTO managers (managerFirstName, managerLastName, managerMail) VALUES ($1, $2, $3)',
                    'user_manager' => 'INSERT INTO user_managers (user_id, manager_id) VALUES ($1, $2)',
                    default => null,
                };

                if ($insert_query) {
                    $line_number = 1;
                    $success_count = 0;
                    $error_count = 0;

                    while (($data = fgetcsv($file)) !== false) {
                        try {
                            $result = match ($type) {
                                'user' => pg_query_params($conn, $insert_query, [
                                    $data[0], // username
                                    $data[1], // mail
                                    $data[2], // pass
                                    $data[3], // firstname
                                    $data[4], // lastname
                                    $data[5], // cluster
                                    filter_var($data[6], FILTER_VALIDATE_BOOLEAN) ? 'true' : 'false', // validationstate
                                    $data[7] ?: null, // validationdate
                                    $data[8] ?: null, // validationexpirationdate
                                    $data[9], // manager
                                    $data[10], // team
                                    filter_var($data[11], FILTER_VALIDATE_BOOLEAN) ? 'true' : 'false' // isadmin
                                ]),
                                'manager' => pg_query_params($conn, $insert_query, [$data[0], $data[1], $data[2]]),
                                'user_manager' => pg_query_params($conn, $insert_query, [$data[0], $data[1]]),
                                default => false,
                            };

                            if ($result) {
                                $success_count++;
                                debug_message("Ligne $line_number : Importée avec succès.");
                            } else {
                                $error_count++;
                                debug_message("Ligne $line_number : Erreur lors de l'importation - " . pg_last_error($conn));
                            }
                        } catch (Exception $e) {
                            $error_count++;
                            debug_message("Ligne $line_number : Exception - " . $e->getMessage());
                        }
                        $line_number++;
                    }
                    fclose($file);

                    echo "<script>alert('Importation terminée. Succès : $success_count, Échecs : $error_count.');</script>";
                    debug_message("Importation terminée : $success_count lignes importées avec succès, $error_count erreurs.");
                }
            } else {
                echo "<script>alert('Le format du fichier est invalide.');</script>";
                debug_message("Format invalide. Fichier non importé.");
                unlink($target_file);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="user.css"/>
    <link rel="stylesheet" href="../../../style/main.css"/>
    <title>Gestion des CSV Utilisateurs</title>
</head>
<body>

<div class="documentation-csv">

    <!-- Documentation Utilisateur -->
    <div class="documentation-part">
        <div class="documentation-title"><h2>Documentation CSV User</h2></div>
        <div class="documentation-image"><img src="../../../../public/src/images/user_csv.png" alt="Documentation CSV User"></div>
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="csv_file" accept=".csv" required>
            <input type="hidden" name="type" value="user">
            <button type="submit">Envoyer</button>
        </form>
    </div>

    <!--

    Documentation Manager 
    <div class="documentation-part">
        <div class="documentation-title"><h2>Documentation CSV Manager</h2></div>
        <div class="documentation-image"><img src="../../../public/src/images/manager_csv.png" alt="Documentation CSV Manager"></div>
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="csv_file" accept=".csv" required>
            <input type="hidden" name="type" value="manager">
            <button type="submit">Envoyer</button>
        </form>
    </div>

    Documentation Manager-Utilisateurs 
    <div class="documentation-part">
        <div class="documentation-title"><h2>Documentation CSV User-Manager</h2></div>
        <div class="documentation-image"><img src="../../../public/src/images/user-manager_csv.png" alt="Documentation CSV User-Manager"></div>
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="csv_file" accept=".csv" required>
            <input type="hidden" name="type" value="user_manager">
            <button type="submit">Envoyer</button>
        </form>
    </div>
    -->
</div>
<script>
    // Détecter quand la souris quitte la fenêtre
    document.addEventListener('mouseleave', function() {
        document.body.classList.add('screenshot-blocked');
    });

    // Détecter quand la souris revient sur la fenêtre
    document.addEventListener('mouseenter', function() {
        document.body.classList.remove('screenshot-blocked');
    });
</script>
</body>
</html>