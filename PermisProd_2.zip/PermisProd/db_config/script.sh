#!/bin/bash

# Fichiers d'entrée et de sortie
input_file="export_csv.csv"
output_themes="result/themes.csv"
output_questions="result/questions.csv"
output_answers="result/answers.csv"

# Fichiers temporaires
temp_themes="result/temp_themes.csv"

# En-têtes des fichiers de sortie
echo "id,theme" > $temp_themes
echo "id,question,theme_id" > $output_questions
echo "question_id,answer_text,is_correct" > $output_answers

# Variables
theme_id=1
question_id=1

# Lire le fichier ligne par ligne (ignorer l'en-tête)
tail -n +2 "$input_file" | while IFS='|' read -r question_number theme question response1 response1_correct response2 response2_correct response3 response3_correct response4 response4_correct; do
    # Nettoyer les données : suppression des espaces, guillemets et normalisation des caractères
    theme=$(echo "$theme" | sed 's/^"//;s/"$//;s/\r//')
    question=$(echo "$question" | sed 's/^"//;s/"$//;s/\r//')
    response1=$(echo "$response1" | sed 's/^"//;s/"$//;s/\r//')
    response2=$(echo "$response2" | sed 's/^"//;s/"$//;s/\r//')
    response3=$(echo "$response3" | sed 's/^"//;s/"$//;s/\r//')
    response4=$(echo "$response4" | sed 's/^"//;s/"$//;s/\r//')

    # Vérifier si le thème existe déjà dans le fichier temporaire des thèmes
    if ! grep -q "^.*,$theme\$" "$temp_themes"; then
        # Si le thème n'existe pas, l'ajouter avec un nouvel ID
        echo "$theme_id,$theme" >> $temp_themes
        current_theme_id=$theme_id
        theme_id=$((theme_id + 1))
    else
        # Si le thème existe, récupérer son ID
        current_theme_id=$(grep "^.*,$theme\$" $temp_themes | cut -d',' -f1)
    fi

    # Ajouter la question au fichier questions.csv
    echo "$question_id,\"$question\",$current_theme_id" >> $output_questions

    # Ajouter les réponses associées à la question
    if [[ -n "$response1" ]]; then
        echo "$question_id,\"$response1\",$response1_correct" >> $output_answers
    fi
    if [[ -n "$response2" ]]; then
        echo "$question_id,\"$response2\",$response2_correct" >> $output_answers
    fi
    if [[ -n "$response3" ]]; then
        echo "$question_id,\"$response3\",$response3_correct" >> $output_answers
    fi
    if [[ -n "$response4" ]]; then
        echo "$question_id,\"$response4\",$response4_correct" >> $output_answers
    fi

    # Incrémenter l'ID de la question
    question_id=$((question_id + 1))
done

# Générer le fichier final des thèmes sans les IDs
echo "theme_name" > $output_themes
tail -n +2 "$temp_themes" | cut -d',' -f2 >> $output_themes

# Nettoyage des fichiers temporaires
rm -f $temp_themes

echo "Fichiers générés : $output_themes, $output_questions et $output_answers"
