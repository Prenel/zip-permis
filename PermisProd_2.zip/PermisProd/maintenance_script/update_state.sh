## ADD THE FONCTONIALITY TO SEND AN EMAIL WHEN THE STATE CHANGE 

#!/bin/bash

# Connexion à la base de données PostgreSQL
conn="host=162.19.254.218 dbname=permisprod user=test password=@test2024 port=5434"

# Récupérer la date actuelle
current_date=$(date +'%Y-%m-%d')

# Exécuter la requête SQL pour mettre à jour les utilisateurs dont la date d'expiration est aujourd'hui
psql "$conn" <<EOF
UPDATE users
SET validationState = false
WHERE validationExpirationDate::date = '$current_date' AND validationState = true;
EOF

# Vérification du succès de la mise à jour
if [ $? -eq 0 ]; then
    echo "Mise à jour des états de validation réussie."
else
    echo "Erreur lors de la mise à jour des états de validation."
fi