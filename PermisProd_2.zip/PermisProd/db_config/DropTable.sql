DROP TABLE questions, answer, theme CASCADE;
TRUNCATE TABLE answer, questions, theme RESTART IDENTITY CASCADE;
