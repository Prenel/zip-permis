<?php
ob_start();
require '../../../../config/conf_header.php';
require '../../../../src/view/component/header.php';
require '../../../controller/User/log/checkIsAdmin.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Gestion des opérations : Ajouter, Modifier, Supprimer
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        switch ($action) {
            case 'add':
                $theme_id = $_POST['theme_id'];
                $question = $_POST['question'];

                // Ajouter la question et récupérer l'ID généré
                $result = pg_query_params($conn,
                    "INSERT INTO questions (id, question, theme_id) VALUES (nextval('questions_id_seq'), $1, $2) RETURNING id",
                    [$question, $theme_id]
                );
                if (!$result) {
                    die("Erreur : Impossible d'ajouter la question.");
                }
                $question_id = pg_fetch_result($result, 0, 'id');

                // Ajouter les réponses
                $answers = [
                    ['text' => $_POST['answer1'], 'is_correct' => ($_POST['is_correct1'] === 'true') ? 'TRUE' : 'FALSE'],
                    ['text' => $_POST['answer2'], 'is_correct' => ($_POST['is_correct2'] === 'true') ? 'TRUE' : 'FALSE'],
                    ['text' => $_POST['answer3'] ?? '/', 'is_correct' => ($_POST['is_correct3'] === 'true') ? 'TRUE' : 'FALSE'],
                    ['text' => $_POST['answer4'] ?? '/', 'is_correct' => ($_POST['is_correct4'] === 'true') ? 'TRUE' : 'FALSE'],
                ];

                foreach ($answers as $answer) {
                    if (!empty($answer['text']) && $answer['text'] !== '/') {
                        $result = pg_query_params($conn,
                            "INSERT INTO answer (id, answer_text, is_correct, question_id)
                             VALUES (nextval('answer_id_seq'), $1, $2, $3)",
                            [$answer['text'], $answer['is_correct'], $question_id]
                        );
                        if (!$result) {
                            die("Erreur : Impossible d'ajouter la réponse.");
                        }
                    }
                }
                break;

            case 'edit':
                $question_id = $_POST['question_id'];
                $question = $_POST['question'];
            
                // Vérifier que question_id et question existent
                if (empty($question_id)) {
                    die("Erreur : question_id manquant.");
                }
            
                if (empty($question)) {
                    die("Erreur : Le texte de la question ne peut pas être vide.");
                }
            
                // Mettre à jour la question
                $update_question = pg_query_params($conn,
                    "UPDATE questions SET question = $1 WHERE id = $2",
                    [$question, $question_id]
                );
                if (!$update_question) {
                    die("Erreur SQL (question) : " . pg_last_error($conn));
                }
            
                // Supprimer toutes les réponses associées à cette question
                $delete_answers = pg_query_params($conn,
                    "DELETE FROM answer WHERE question_id = $1",
                    [$question_id]
                );
                if (!$delete_answers) {
                    die("Erreur SQL (delete answers) : " . pg_last_error($conn));
                }
            
                // Ajouter les nouvelles réponses
                $answers = [
                    ['text' => $_POST['answer1'] ?? null, 'is_correct' => ($_POST['is_correct1'] ?? 'false') === 'true' ? 'TRUE' : 'FALSE'],
                    ['text' => $_POST['answer2'] ?? null, 'is_correct' => ($_POST['is_correct2'] ?? 'false') === 'true' ? 'TRUE' : 'FALSE'],
                    ['text' => $_POST['answer3'] ?? null, 'is_correct' => ($_POST['is_correct3'] ?? 'false') === 'true' ? 'TRUE' : 'FALSE'],
                    ['text' => $_POST['answer4'] ?? null, 'is_correct' => ($_POST['is_correct4'] ?? 'false') === 'true' ? 'TRUE' : 'FALSE'],
                ];
            
                foreach ($answers as $answer) {
                    if (!empty($answer['text'])) {
                        $add_answer = pg_query_params($conn,
                            "INSERT INTO answer (id, answer_text, is_correct, question_id)
                                VALUES (nextval('answer_id_seq'), $1, $2, $3)",
                            [$answer['text'], $answer['is_correct'], $question_id]
                        );
                        if (!$add_answer) {
                            die("Erreur SQL (add answer) : " . pg_last_error($conn));
                        }
                    }
                }
                break;

            case 'delete':
                $question_id = $_POST['question_id'];

                // Supprimer les réponses associées
                pg_query_params($conn, "DELETE FROM answer WHERE question_id = $1", [$question_id]);

                // Supprimer la question
                pg_query_params($conn, "DELETE FROM questions WHERE id = $1", [$question_id]);
                break;

            case 'delete_answer':
                $answer_id = $_POST['answer_id'];

                if (!empty($answer_id)) {
                    $delete_answer = pg_query_params($conn,
                        "DELETE FROM answer WHERE id = $1",
                        [$answer_id]
                    );
                    if (!$delete_answer) {
                        die("Erreur : Impossible de supprimer la réponse.");
                    }
                }
                break;

            case 'add_answer':
                $question_id = $_POST['question_id'];
                $answer_text = $_POST['answer_text'];
                $is_correct = ($_POST['is_correct'] === 'true') ? 'TRUE' : 'FALSE';

                if (!empty($question_id) && !empty($answer_text)) {
                    $add_answer = pg_query_params($conn,
                        "INSERT INTO answer (id, answer_text, is_correct, question_id)
                         VALUES (nextval('answer_id_seq'), $1, $2, $3)",
                        [$answer_text, $is_correct, $question_id]
                    );
                    if (!$add_answer) {
                        die("Erreur : Impossible d'ajouter la réponse.");
                    }
                }
                break;
            case 'add_theme':
                $theme_name = $_POST['theme_name'];
                pg_query_params($conn, "INSERT INTO theme (theme_name) VALUES ($1)", [$theme_name]);
                break;
            
            case 'edit_theme':
                $theme_id = $_POST['theme_id'];
                $theme_name = $_POST['theme_name'];
                pg_query_params($conn, "UPDATE theme SET theme_name = $1 WHERE id = $2", [$theme_name, $theme_id]);
                break;
            
            case 'delete_theme':
                $theme_id = $_POST['theme_id'];
                pg_query_params($conn, "DELETE FROM theme WHERE id = $1", [$theme_id]);
                break;
            // case 'truncate_question':
            //     // Vider les tables et réinitialiser les séquences
            //     pg_query($conn, "TRUNCATE TABLE answer, questions, theme RESTART IDENTITY CASCADE;");
            //     break;
                
        }
    }
}

$order_by = $_GET['order_by'] ?? 'theme_name';
$order_dir = $_GET['order_dir'] ?? 'asc';

$data = pg_query($conn, "
    SELECT 
        theme.id AS theme_id, theme.theme_name,
        questions.id AS question_id, questions.question,
        answer.id AS answer_id, answer.answer_text, answer.is_correct
    FROM theme
    JOIN questions ON theme.id = questions.theme_id
    LEFT JOIN answer ON questions.id = answer.question_id
    ORDER BY $order_by $order_dir, answer.id
");


$order_by_themes = $_GET['order_by_themes'] ?? 'id';
$order_dir_themes = $_GET['order_dir_themes'] ?? 'asc';

$themes = pg_query($conn, "SELECT * FROM theme ORDER BY $order_by_themes $order_dir_themes");

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Thèmes, Questions et Réponses</title>
    <link rel="stylesheet" href="question.css"/>
    <link rel="stylesheet" href="../../../style/main.css"/>
</head>
<body>
    <h1>Gestion des Thèmes, Questions et Réponses</h1>
    <div class="csv-presentation">
        <h3><a href="question_csv.php"> ➡️ CSV ADD </a></h3>
    </div>
    <table>
        <thead>
            <tr>
                <th>
                    <a href="?order_by=question_id&order_dir=<?= $order_dir === 'asc' ? 'desc' : 'asc' ?>" 
                    style="<?= $order_by === 'question_id' ? 'text-decoration: underline;' : '' ?>">
                        ID <?= $order_by === 'question_id' ? ($order_dir === 'asc' ? '⬆️' : '⬇️') : '⬍' ?>
                    </a>
                </th>
                <th>
                    <a href="?order_by=theme_name&order_dir=<?= $order_dir === 'asc' ? 'desc' : 'asc' ?>" 
                    style="<?= $order_by === 'theme_name' ? 'text-decoration: underline;' : '' ?>">
                        Thème <?= $order_by === 'theme_name' ? ($order_dir === 'asc' ? '⬆️' : '⬇️') : '⬍' ?>
                    </a>
                </th>
                <th>
                    <a href="?order_by=question&order_dir=<?= $order_dir === 'asc' ? 'desc' : 'asc' ?>" 
                    style="<?= $order_by === 'question' ? 'text-decoration: underline;' : '' ?>">
                        Question <?= $order_by === 'question' ? ($order_dir === 'asc' ? '⬆️' : '⬇️') : '⬍' ?>
                    </a>
                </th>
                <th>Réponse 1</th>
                <th>Réponse 2</th>
                <th>Réponse 3</th>
                <th>Réponse 4</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
            $current_question = null;
            $answers = [];
            while ($row = pg_fetch_assoc($data)) {
                if ($current_question !== $row['question_id']) {
                    if ($current_question) {
                        while (count($answers['answers']) < 4) {
                            $answers['answers'][] = ['text' => '/', 'is_correct' => 'f', 'id' => null];
                        }

                        echo "<tr>
                            <form method='POST'>
                                <td>{$answers['question_id']}</td>
                                <td>{$answers['theme_name']}</td>
                                <td>
                                    <input type='text' name='question' value='" . htmlspecialchars($answers['question'], ENT_QUOTES) . "' required>
                                    <input type='hidden' name='question_id' value='" . htmlspecialchars($answers['question_id']) . "'>
                                </td>";

                        foreach ($answers['answers'] as $i => $answer) {
                            echo "<td>
                                    <input type='text' name='answer" . ($i + 1) . "' value='" . htmlspecialchars($answer['text'], ENT_QUOTES) . "'>
                                    <select name='is_correct" . ($i + 1) . "'>
                                        <option value='true'" . (($answer['is_correct'] === 't') ? ' selected' : '') . ">✔️</option>
                                        <option value='false'" . (($answer['is_correct'] === 'f') ? ' selected' : '') . ">❌</option>
                                    </select>
                                </td>";
                        }

                        echo "<td>
                                <button type='submit' name='action' value='edit'>Modifier</button>
                                <button type='submit' name='action' value='delete' style='color: red;'>Supprimer</button>
                            </td>
                            </form>
                        </tr>";
                    }

                    $current_question = $row['question_id'];
                    $answers = [
                        'theme_name' => $row['theme_name'],
                        'question' => $row['question'],
                        'question_id' => $row['question_id'],
                        'answers' => []
                    ];
                }

                $answers['answers'][] = [
                    'text' => $row['answer_text'] ?? '/',
                    'is_correct' => $row['is_correct'] ?? 'f',
                    'id' => $row['answer_id'] ?? null
                ];
            }

            if ($current_question) {
                while (count($answers['answers']) < 4) {
                    $answers['answers'][] = ['text' => '/', 'is_correct' => 'f', 'id' => null];
                }

                echo "<tr>
                    <form method='POST'>
                        <td>" . htmlspecialchars($answers['theme_name']) . "</td>
                        <td>
                            <input type='text' name='question' value='" . htmlspecialchars($answers['question'], ENT_QUOTES) . "' required>
                            <input type='hidden' name='question_id' value='" . htmlspecialchars($answers['question_id']) . "'>
                        </td>";

                foreach ($answers['answers'] as $index => $answer) {
                    echo "<td>
                            <input type='text' name='answer" . ($index + 1) . "' value='" . htmlspecialchars($answer['text'], ENT_QUOTES) . "'>
                            <select name='is_correct" . ($index + 1) . "'>
                                <option value='true'" . (($answer['is_correct'] === 't') ? ' selected' : '') . ">✔️</option>
                                <option value='false'" . (($answer['is_correct'] === 'f') ? ' selected' : '') . ">❌</option>
                            </select>
                        </td>";
                }

                echo "<td>
                        <button type='submit' name='action' value='edit'>Modifier</button>
                        <button type='submit' name='action' value='delete' style='color: red;'>Supprimer</button>
                    </td>
                    </form>
                </tr>";
            }
            ?>
        </tbody>
    </table>

    <?php
        // Récupérer le max ID des questions
        $max_id_query = pg_query($conn, "SELECT MAX(id) AS max_id FROM questions");
        $max_id_row = pg_fetch_assoc($max_id_query);
        $max_id = $max_id_row['max_id'];
    ?>

    <!-- Ajouter cette ligne à la fin du tableau des questions -->
    <tfoot>
        <tr>
            <td colspan="8" style="text-align: center;">
                <strong>Max ID des questions : <?= htmlspecialchars($max_id) ?></strong>
                <!-- Formulaire pour vider les tables -->
<!--                 <form method="POST" style="display: inline-block; margin-left: 20px;" onsubmit="return confirm('Êtes-vous sûr de vouloir vider toutes les tables ? Cette action est irréversible.');">
                    <input type="hidden" name="action" value="truncate_question">
                    <button type="submit" style="color: red; background: none; border: none; cursor: pointer;">Vider les tables (Questions, Réponses, Thèmes)</button>
                </form> -->
            </td>
        </tr>
    </tfoot>

    <h2>Gestion des Thèmes</h2>
    <table>
        <thead>
            <tr>
                <th><a href="?order_by_themes=id&order_dir_themes=<?= $order_dir_themes === 'asc' ? 'desc' : 'asc' ?>">ID <?= $order_by_themes === 'id' ? ($order_dir_themes === 'asc' ? '⬆️' : '⬇️') : '' ?></a></th>
                <th><a href="?order_by_themes=theme_name&order_dir_themes=<?= $order_dir_themes === 'asc' ? 'desc' : 'asc' ?>">Nom du Thème <?= $order_by_themes === 'theme_name' ? ($order_dir_themes === 'asc' ? '⬆️' : '⬇️') : '' ?></a></th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($theme = pg_fetch_assoc($themes)) : ?>
                <tr>
                    <form method="POST">
                        <td><?= htmlspecialchars($theme['id']) ?></td>
                        <td>
                            <input type="text" name="theme_name" value="<?= htmlspecialchars($theme['theme_name'], ENT_QUOTES) ?>" required>
                            <input type="hidden" name="theme_id" value="<?= htmlspecialchars($theme['id']) ?>">
                        </td>
                        <td>
                            <button type="submit" name="action" value="edit_theme">Modifier</button>
                            <button type="submit" name="action" value="delete_theme" style="color: red;">Supprimer</button>
                        </td>
                    </form>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <?php
        // Récupérer le max ID des thèmes
        $max_id_theme_query = pg_query($conn, "SELECT MAX(id) AS max_id FROM theme");
        $max_id_theme_row = pg_fetch_assoc($max_id_theme_query);
        $max_id_theme = $max_id_theme_row['max_id'];
    ?>

    <!-- Ajouter cette ligne à la fin du tableau des thèmes -->
    <tfoot>
        <tr>
            <td colspan="3" style="text-align: center;">
                <strong>Max ID des thèmes : <?= htmlspecialchars($max_id_theme) ?></strong>
            </td>
        </tr>
    </tfoot>

    <h2>Ajouter un Nouveau Thème</h2>
    <form method="POST">
        <input type="hidden" name="action" value="add_theme">
        <input type="text" name="theme_name" placeholder="Nom du Thème" required>
        <button type="submit">Ajouter</button>
    </form>


    <h2>Ajouter une nouvelle question</h2>
    <form method="POST">
        <input type="hidden" name="action" value="add">
        <label>Thème :</label>
        <select name="theme_id" required>
            <option value="">Choisir un thème</option>
            <?php while ($theme = pg_fetch_assoc($themes)): ?>
                <option value="<?= htmlspecialchars($theme['id']) ?>"><?= htmlspecialchars($theme['theme_name']) ?></option>
            <?php endwhile; ?>
        </select>
        <input type="text" name="question" placeholder="Question" required>
        <fieldset>
            <legend>Réponses :</legend>
            <div>
                <input type="text" name="answer1" placeholder="Réponse 1" required>
                <select name="is_correct1">
                    <option value="true">Correct</option>
                    <option value="false">Incorrect</option>
                </select>
            </div>
            <div>
                <input type="text" name="answer2" placeholder="Réponse 2" required>
                <select name="is_correct2">
                    <option value="true">Correct</option>
                    <option value="false">Incorrect</option>
                </select>
            </div>
            <div>
                <input type="text" name="answer3" placeholder="Réponse 3">
                <select name="is_correct3">
                    <option value="true">Correct</option>
                    <option value="false">Incorrect</option>
                </select>
            </div>
            <div>
                <input type="text" name="answer4" placeholder="Réponse 4">
                <select name="is_correct4">
                    <option value="true">Correct</option>
                    <option value="false">Incorrect</option>
                </select>
            </div>
        </fieldset>
        <button type="submit">Ajouter</button>
    </form>
    <script>
        // Détecter quand la souris quitte la fenêtre
        document.addEventListener('mouseleave', function() {
            document.body.classList.add('screenshot-blocked');
        });

        // Détecter quand la souris revient sur la fenêtre
        document.addEventListener('mouseenter', function() {
            document.body.classList.remove('screenshot-blocked');
        });
    </script>
</body>
</html>